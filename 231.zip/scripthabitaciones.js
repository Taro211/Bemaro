document.addEventListener('DOMContentLoaded', function() {
    // Inicializar los componentes de la página
    initModalHabitaciones();
    initAnimaciones();
    
    // Comprobar si hay un identificador de habitación en la URL
    checkRoomInURL();
    
    // Remover cualquier splash screen residual si existe
    const splashScreen = document.querySelector('.splash-screen');
    if (splashScreen) {
        splashScreen.remove();
    }
});



// Función para inicializar el modal de detalles de habitaciones
function initModalHabitaciones() {
    const modal = document.getElementById('habitacionModal');
    const detallesBtns = document.querySelectorAll('.habitacion-btn.detalles');
    const closeBtn = document.querySelector('.modal-cerrar');
    
    if (!modal || !detallesBtns.length || !closeBtn) return;
    
    // Base de datos de habitaciones para el modal
    const habitacionesData = {
        individual: {
            title: "Habitación Individual",
            images: [
                { src: "imagenes/habitaciones/1.jpg", caption: "Vista general de la habitación individual" },
                { src: "imagenes/habitaciones/2.jpg", caption: "Baño privado con ducha" },
                { src: "imagenes/habitaciones/3.jpg", caption: "Área de trabajo" }
            ],
            description: `
                <p>La <strong>Habitación Individual</strong> es perfecta para viajeros solitarios que buscan comodidad y privacidad. Con una cuidadosa combinación de funcionalidad y estilo, esta habitación ofrece todo lo necesario para una estancia placentera.</p>
                <p>Disfruta de un espacio íntimo pero bien equipado, con una cama individual cómoda, un área de trabajo funcional y un baño privado. La habitación cuenta con excelente iluminación natural durante el día y un ambiente acogedor por la noche.</p>
                <p>Ideal para viajeros de negocios o turistas que prefieren un espacio personal para descansar después de un día explorando la Ciudad de México.</p>
            `,
            features: [
                { icon: "fas fa-user", text: "Capacidad para 1 persona" },
                { icon: "fas fa-bed", text: "Cama individual con colchón ortopédico" },
                { icon: "fas fa-shower", text: "Baño privado con ducha" },
                { icon: "fas fa-wifi", text: "WiFi gratis de alta velocidad" },
                { icon: "fas fa-tv", text: "Smart TV 32\" con Netflix y YouTube" },
                { icon: "fas fa-snowflake", text: "Aire acondicionado individual" },
                { icon: "fas fa-mug-hot", text: "Cafetera" },
                { icon: "fas fa-door-closed", text: "Caja fuerte digital" }
            ],
            services: [
                { icon: "fas fa-coffee", text: "Desayuno continental incluido" },
                { icon: "fas fa-concierge-bell", text: "Servicio de limpieza diario" },
                { icon: "fas fa-soap", text: "Artículos de aseo básicos" },
                { icon: "fas fa-phone-alt", text: "Servicio de despertador" },
                { icon: "fas fa-briefcase", text: "Guardaequipaje gratuito" },
                { icon: "fas fa-utensils", text: "Descuento en restaurantes asociados" }
            ]
        },
        doble: {
            title: "Habitación Doble",
            images: [
                { src: "imagenes/habitaciones/1.jpg", caption: "Vista general de la habitación doble" },
                { src: "imagenes/habitaciones/2.jpg", caption: "Baño privado con ducha" },
                { src: "imagenes/habitaciones/3.jpg", caption: "Vista al patio interior" }
            ],
            description: `
                <p>Nuestra <strong>Habitación Doble</strong> es espaciosa y confortable, perfecta para parejas o amigos que viajan juntos. Este acogedor espacio combina elegancia y funcionalidad para brindar una experiencia de alojamiento superior.</p>
                <p>La habitación cuenta con una cama matrimonial premium con sábanas de algodón egipcio, una zona de estar con dos sillones cómodos, y un baño privado completamente equipado. La decoración contemporánea y los detalles cuidadosamente seleccionados crean un ambiente relajante.</p>
                <p>Disfruta de vistas a la calle o al patio interior, dependiendo de disponibilidad, y de todas las comodidades modernas que necesitas para una estancia inolvidable en el corazón de la Ciudad de México.</p>
            `,
            features: [
                { icon: "fas fa-users", text: "Capacidad para 2 personas" },
                { icon: "fas fa-bed", text: "Cama matrimonial tamaño queen" },
                { icon: "fas fa-shower", text: "Baño privado con ducha" },
                { icon: "fas fa-wifi", text: "WiFi gratis de alta velocidad" },
                { icon: "fas fa-tv", text: "Smart TV 40\" con servicios de streaming" },
                { icon: "fas fa-snowflake", text: "Control de temperatura individual" },
                { icon: "fas fa-glass-martini-alt", text: "Minibar" },
                { icon: "fas fa-cookie", text: "Selección de té y café" }
            ],
            services: [
                { icon: "fas fa-coffee", text: "Desayuno buffet incluido" },
                { icon: "fas fa-concierge-bell", text: "Servicio de limpieza diario" },
                { icon: "fas fa-soap", text: "Artículos de aseo premium" },
                { icon: "fas fa-broom", text: "Servicio de turndown (preparación nocturna)" },
                { icon: "fas fa-tshirt", text: "Plancha y tabla de planchar disponibles" },
                { icon: "fas fa-map", text: "Servicio de concierge" }
            ]
        },
        familiar: {
            title: "Habitación Familiar",
            images: [
                { src: "imagenes/habitaciones/1.jpg", caption: "Vista general de la habitación familiar" },
                { src: "imagenes/habitaciones/2.jpg", caption: "Área común para familias" },
                { src: "imagenes/habitaciones/3.jpg", caption: "Baño amplio y funcional" }
            ],
            description: `
                <p>La <strong>Habitación Familiar</strong> ofrece un amplio espacio diseñado pensando en la comodidad de familias o grupos pequeños. Con una superficie más generosa, esta habitación permite que todos tengan su espacio personal sin sacrificar la convivencia.</p>
                <p>Equipada con dos camas dobles tamaño matrimonial, un sofá cama adicional, un baño amplio con ducha y bañera, y una zona de estar con mesa y sillas. La habitación también incluye una pequeña zona de cocina con refrigerador y microondas, perfecta para familias con niños o estancias prolongadas.</p>
                <p>Disfrutarás de vistas al jardín o a la ciudad y de todas las comodidades necesarias para que tu familia se sienta como en casa durante su visita a la Ciudad de México.</p>
            `,
            features: [
                { icon: "fas fa-users", text: "Capacidad para 4-5 personas" },
                { icon: "fas fa-bed", text: "2 camas matrimoniales" },
                { icon: "fas fa-couch", text: "Sofá cama adicional" },
                { icon: "fas fa-bath", text: "Baño familiar con ducha y bañera" },
                { icon: "fas fa-wifi", text: "WiFi gratis de alta velocidad" },
                { icon: "fas fa-tv", text: "Smart TV 50\" con canales infantiles" },
                { icon: "fas fa-utensils", text: "Refrigerador y microondas" },
                { icon: "fas fa-gamepad", text: "Juegos de mesa para familia" }
            ],
            services: [
                { icon: "fas fa-coffee", text: "Desayuno buffet completo incluido" },
                { icon: "fas fa-concierge-bell", text: "Servicio de limpieza diario" },
                { icon: "fas fa-baby", text: "Cunas disponibles sin cargo" },
                { icon: "fas fa-map-marked-alt", text: "Recomendaciones de actividades familiares" },
                { icon: "fas fa-suitcase", text: "Espacio extra para equipaje" },
                { icon: "fas fa-user-shield", text: "Servicio de niñera (con cargo adicional)" }
            ]
        },
        suite: {
            title: "Suite Deluxe",
            images: [
                { src: "imagenes/habitaciones/1.jpg", caption: "Vista general de la suite deluxe" },
                { src: "imagenes/habitaciones/2.jpg", caption: "Sala de estar separada" },
                { src: "imagenes/habitaciones/3.jpg", caption: "Baño de lujo con jacuzzi" }
            ],
            description: `
                <p>La <strong>Suite Deluxe</strong> representa nuestra experiencia de alojamiento más premium. Este espacio de lujo cuenta con un diseño elegante y sofisticado, materiales de la más alta calidad y vistas panorámicas espectaculares de la Ciudad de México.</p>
                <p>Con un dormitorio separado con cama king size de lujo, una amplia sala de estar, vestidor y un lujoso baño con jacuzzi y ducha de efecto lluvia. El mobiliario está cuidadosamente seleccionado para brindar máximo confort, con detalles artesanales y acabados de lujo.</p>
                <p>Disfruta de servicios exclusivos como atención personalizada, check-in y check-out privados, y un conjunto de amenidades premium. La Suite Deluxe es ideal para viajeros que buscan una experiencia extraordinaria y momentos memorables en la Ciudad de México.</p>
            `,
            features: [
                { icon: "fas fa-users", text: "Capacidad para 2 personas" },
                { icon: "fas fa-bed", text: "Cama king size con colchón premium" },
                { icon: "fas fa-bath", text: "Baño lujoso con jacuzzi y ducha de lluvia" },
                { icon: "fas fa-couch", text: "Sala de estar separada" },
                { icon: "fas fa-wifi", text: "WiFi premium de alta velocidad" },
                { icon: "fas fa-tv", text: "Smart TV 55\" con sistema de sonido" },
                { icon: "fas fa-wine-glass-alt", text: "Minibar premium con selección de vinos" },
                { icon: "fas fa-mountain", text: "Terraza privada con vistas panorámicas" }
            ],
            services: [
                { icon: "fas fa-utensils", text: "Desayuno gourmet a la carta" },
                { icon: "fas fa-concierge-bell", text: "Servicio de limpieza 2 veces al día" },
                { icon: "fas fa-glass-cheers", text: "Botella de vino de bienvenida" },
                { icon: "fas fa-car", text: "Traslado gratuito al aeropuerto" },
                { icon: "fas fa-clock", text: "Check-in y check-out flexibles" },
                { icon: "fas fa-user-tie", text: "Mayordomo personal (bajo petición)" },
                { icon: "fas fa-spa", text: "Acceso a área de bienestar" }
            ]
        },
        superior: {
            title: "Habitación Superior",
            images: [
                { src: "imagenes/habitaciones/1.jpg", caption: "Vista general de la habitación superior" },
                { src: "imagenes/habitaciones/2.jpg", caption: "Baño premium renovado" },
                { src: "imagenes/habitaciones/3.jpg", caption: "Vistas panorámicas desde la habitación" }
            ],
            description: `
                <p>La <strong>Habitación Superior</strong> es una versión mejorada de nuestra habitación individual, diseñada para brindar una experiencia de alojamiento elevada para el viajero solitario exigente.</p>
                <p>Esta habitación de categoría superior cuenta con una cama queen size ultra cómoda, un área de trabajo ergonómica, un baño premium completamente renovado y vistas panorámicas de la ciudad o del jardín interior. El espacio adicional te permite disfrutar de mayor comodidad.</p>
                <p>La decoración contemporánea con toques artesanales mexicanos, la iluminación ambiental ajustable y los materiales de alta calidad crean un entorno sofisticado y acogedor para tu estancia en la Ciudad de México.</p>
            `,
            features: [
                { icon: "fas fa-user", text: "Capacidad para 1 persona" },
                { icon: "fas fa-bed", text: "Cama queen size con sábanas premium" },
                { icon: "fas fa-shower", text: "Baño premium con ducha de lluvia" },
                { icon: "fas fa-door-open", text: "Balcón o ventana panorámica" },
                { icon: "fas fa-wifi", text: "WiFi de alta velocidad" },
                { icon: "fas fa-tv", text: "Smart TV 42\" con sistema de sonido" },
                { icon: "fas fa-mug-hot", text: "Máquina de café espresso" },
                { icon: "fas fa-tshirt", text: "Bata y zapatillas de baño" }
            ],
            services: [
                { icon: "fas fa-coffee", text: "Desayuno continental mejorado" },
                { icon: "fas fa-concierge-bell", text: "Servicio de limpieza diario" },
                { icon: "fas fa-soap", text: "Artículos de aseo premium" },
                { icon: "fas fa-glass-martini", text: "Bebida de bienvenida" },
                { icon: "fas fa-book", text: "Selección de libros y revistas" },
                { icon: "fas fa-headphones", text: "Acceso a colección de música" }
            ]
        },
        individual2: {
            title: "Habitación Idividual",
            images: [
                { src: "imagenes/habitaciones/6.jpg", caption: "Vista general de la habitación individual" },
                { src: "imagenes/habitaciones/2.jpg", caption: "Baño privado con ducha" },
                { src: "imagenes/habitaciones/3.jpg", caption: "Área de trabajo" }
            ],
            description: `
                <p>La <strong>Habitación Individual</strong> es perfecta para viajeros solitarios que buscan comodidad y privacidad. Con una cuidadosa combinación de funcionalidad y estilo, esta habitación ofrece todo lo necesario para una estancia placentera.</p>
                <p>Disfruta de un espacio íntimo pero bien equipado, con una cama individual cómoda, un área de trabajo funcional y un baño privado. La habitación cuenta con excelente iluminación natural durante el día y un ambiente acogedor por la noche.</p>
                <p>Ideal para viajeros de negocios o turistas que prefieren un espacio personal para descansar después de un día explorando la Ciudad de México.</p>
            `,
            features: [
                { icon: "fas fa-user", text: "Capacidad para 1 persona" },
                { icon: "fas fa-bed", text: "Cama individual con colchón ortopédico" },
                { icon: "fas fa-shower", text: "Baño privado con ducha" },
                { icon: "fas fa-wifi", text: "WiFi gratis de alta velocidad" },
                { icon: "fas fa-tv", text: "Smart TV 32\" con Netflix y YouTube" },
                { icon: "fas fa-snowflake", text: "Aire acondicionado individual" },
                { icon: "fas fa-mug-hot", text: "Cafetera" },
                { icon: "fas fa-door-closed", text: "Caja fuerte digital" }
            ],
            services: [
                { icon: "fas fa-coffee", text: "Desayuno continental incluido" },
                { icon: "fas fa-concierge-bell", text: "Servicio de limpieza diario" },
                { icon: "fas fa-soap", text: "Artículos de aseo básicos" },
                { icon: "fas fa-phone-alt", text: "Servicio de despertador" },
                { icon: "fas fa-briefcase", text: "Guardaequipaje gratuito" },
                { icon: "fas fa-utensils", text: "Descuento en restaurantes asociados" }
            ]
        }
    };
    
    // Variable para almacenar la instancia de Swiper
    let modalSwiper = null;
    
    // Función para abrir el modal
    function openModal(roomType) {
        if (!habitacionesData[roomType]) return;
        
        // Establecer título
        document.getElementById('modalTitle').textContent = habitacionesData[roomType].title;
        
        // Generar contenido del Swiper
        const swiperWrapper = document.querySelector('.swiper-modal-galeria .swiper-wrapper');
        swiperWrapper.innerHTML = '';
        
        habitacionesData[roomType].images.forEach(image => {
            const swiperSlide = document.createElement('div');
            swiperSlide.className = 'swiper-slide';
            
            swiperSlide.innerHTML = `
                <img src="${image.src}" alt="${habitacionesData[roomType].title}" />
                <div class="swiper-caption">${image.caption}</div>
            `;
            
            swiperWrapper.appendChild(swiperSlide);
        });
        
        // Establecer descripción
        document.getElementById('modalDescripcion').innerHTML = habitacionesData[roomType].description;
        
        // Generar listas de características y servicios
        const caracteristicasList = document.getElementById('modalCaracteristicas');
        const serviciosList = document.getElementById('modalServicios');
        
        caracteristicasList.innerHTML = '';
        habitacionesData[roomType].features.forEach(feature => {
            const li = document.createElement('li');
            li.innerHTML = `<i class="${feature.icon}"></i> ${feature.text}`;
            caracteristicasList.appendChild(li);
        });
        
        serviciosList.innerHTML = '';
        habitacionesData[roomType].services.forEach(service => {
            const li = document.createElement('li');
            li.innerHTML = `<i class="${service.icon}"></i> ${service.text}`;
            serviciosList.appendChild(li);
        });
        
        // Mostrar el modal con animación
        modal.classList.add('show');
        setTimeout(() => {
            document.querySelector('.modal-contenido').style.opacity = '1';
            document.querySelector('.modal-contenido').style.transform = 'translateY(0)';
        }, 50);
        
        // Inicializar el Swiper después de que se haya mostrado el modal
        setTimeout(() => {
            // Destruir Swiper anterior si existe
            if (modalSwiper) {
                modalSwiper.destroy(true, true);
            }
            
            // Crear nuevo Swiper
            modalSwiper = new Swiper('.swiper-modal-galeria', {
                slidesPerView: 1,
                spaceBetween: 0,
                loop: true,
                speed: 800,
                autoplay: {
                    delay: 5000,
                    disableOnInteraction: false,
                },
                effect: 'fade',
                fadeEffect: {
                    crossFade: true
                },
                navigation: {
                    nextEl: '.swiper-modal-galeria .swiper-button-next',
                    prevEl: '.swiper-modal-galeria .swiper-button-prev',
                },
                pagination: {
                    el: '.swiper-modal-galeria .swiper-pagination',
                    clickable: true,
                    renderBullet: function (index, className) {
                        return '<span class="' + className + '"></span>';
                    },
                }
            });
        }, 300);
        
        // Bloquear scroll del body
        document.body.style.overflow = 'hidden';
    }
    
    // Función para cerrar el modal
    function closeModal() {
        document.querySelector('.modal-contenido').style.opacity = '0';
        document.querySelector('.modal-contenido').style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            modal.classList.remove('show');
            // Restaurar scroll del body
            document.body.style.overflow = 'auto';
            
            // Destruir Swiper al cerrar
            if (modalSwiper) {
                modalSwiper.destroy(true, true);
                modalSwiper = null;
            }
        }, 300);
    }
    
    // Asignar eventos a los botones de detalles
    detallesBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const roomType = this.getAttribute('data-room');
            openModal(roomType);
        });
    });
    
    // Asignar evento al botón de cerrar
    closeBtn.addEventListener('click', closeModal);
    
    // Cerrar modal al hacer clic fuera del contenido
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModal();
        }
    });
    
    // Cerrar modal con la tecla Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.classList.contains('show')) {
            closeModal();
        }
    });
}

// Función para verificar si hay un parámetro de habitación en la URL
function checkRoomInURL() {
    // Comprobar si hay un hash en la URL
    if (window.location.hash) {
        // Extraer el parámetro de habitación del hash
        const hashParams = window.location.hash.substring(1).split('&');
        for (let i = 0; i < hashParams.length; i++) {
            const param = hashParams[i].split('=');
            if (param[0] === 'room' && param[1]) {
                // Si encontramos un parámetro de habitación, buscamos el botón correspondiente
                const roomType = param[1];
                const roomButton = document.querySelector(`.habitacion-btn.detalles[data-room="${roomType}"]`);
                
                // Si encontramos el botón, simular clic para abrir el modal
                if (roomButton) {
                    // Pequeño retraso para asegurar que todos los componentes estén cargados
                    setTimeout(() => {
                        roomButton.click();
                        
                        // Scroll a la sección de habitaciones para mejor UX
                        const habitacionesSection = document.querySelector('.habitaciones-section');
                        if (habitacionesSection) {
                            habitacionesSection.scrollIntoView({ behavior: 'smooth' });
                        }
                    }, 500);
                }
                break;
            }
        }
    }
}


// Función para inicializar animaciones generales
function initAnimaciones() {
    // Animación al hacer scroll para las tarjetas de habitación
    const habitacionCards = document.querySelectorAll('.habitacion-card');
    
    // Configuración del observador de intersección
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1 // 10% del elemento debe ser visible
    };
    
    // Callback del observador
    const onCardIntersect = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.transition = 'all 0.8s cubic-bezier(0.19, 1, 0.22, 1)';
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                observer.unobserve(entry.target); // Deja de observar el elemento una vez animado
            }
        });
    };
    
    // Crear el observador
    const cardObserver = new IntersectionObserver(onCardIntersect, observerOptions);
    
    // Observar cada tarjeta de habitación
    habitacionCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        cardObserver.observe(card);
    });
    

    
    // Animación para la sección CTA
    const ctaSection = document.querySelector('.cta-habitaciones');
    if (ctaSection) {
        const ctaObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    ctaSection.querySelector('h2').style.opacity = '1';
                    ctaSection.querySelector('h2').style.transform = 'translateY(0)';
                    
                    setTimeout(() => {
                        ctaSection.querySelector('p').style.opacity = '1';
                        ctaSection.querySelector('p').style.transform = 'translateY(0)';
                    }, 200);
                    
                    setTimeout(() => {
                        ctaSection.querySelector('.cta-button').style.opacity = '1';
                        ctaSection.querySelector('.cta-button').style.transform = 'translateY(0)';
                    }, 400);
                    
                    ctaObserver.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.3
        });
        
        // Inicializar estilos para animación
        ctaSection.querySelector('h2').style.opacity = '0';
        ctaSection.querySelector('h2').style.transform = 'translateY(30px)';
        ctaSection.querySelector('h2').style.transition = 'all 0.8s cubic-bezier(0.19, 1, 0.22, 1)';
        
        ctaSection.querySelector('p').style.opacity = '0';
        ctaSection.querySelector('p').style.transform = 'translateY(30px)';
        ctaSection.querySelector('p').style.transition = 'all 0.8s cubic-bezier(0.19, 1, 0.22, 1)';
        
        ctaSection.querySelector('.cta-button').style.opacity = '0';
        ctaSection.querySelector('.cta-button').style.transform = 'translateY(30px)';
        ctaSection.querySelector('.cta-button').style.transition = 'all 0.8s cubic-bezier(0.19, 1, 0.22, 1)';
        
        // Observar la sección CTA
        ctaObserver.observe(ctaSection);
    }
    
    // Efecto parallax suave en el encabezado
    const habitacionesHeader = document.querySelector('.habitaciones-header');
    if (habitacionesHeader) {
        window.addEventListener('scroll', function() {
            const scrollPosition = window.scrollY;
            if (scrollPosition < 600) {
                const translateY = scrollPosition * 0.3;
                habitacionesHeader.style.backgroundPosition = `center ${translateY}px`;
            }
        });
    }
}