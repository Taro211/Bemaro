// Script para el desplazamiento de navegación
document.addEventListener('DOMContentLoaded', function() {
    // DOM element references
    const header = document.querySelector('.header');
    const logoIcon = document.querySelector('.logo-icon');
    const logoName = document.querySelector('.logo-name');
    const themeToggle = document.querySelector('.theme-toggle');
    const toggleThumb = document.querySelector('.toggle-thumb');
    const menuToggle = document.querySelector('.menu-mobile-toggle');
    const menuIcon = document.querySelector('.menu-icon');
    const mobileMenu = document.querySelector('.mobile-menu');
    const mobileMenuItems = document.querySelector('.mobile-menu-items');
    
    // Eliminamos toda la funcionalidad de navegación deslizable
    // ya no necesitamos los botones ni los event listeners
    
    // Apply saved theme preference on page load
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-mode');
    }
    
    // Variables para manejar el scroll
    let lastScrollY = 0;
    let scrollDirection = 'down';
    
    // Improved header scroll animation with smooth transitions in both directions
    const handleScroll = () => {
        const currentScrollY = window.scrollY;
        
        // Determine scroll direction
        scrollDirection = currentScrollY > lastScrollY ? 'down' : 'up';
        lastScrollY = currentScrollY;
        
        // Función para aplicar clases con animaciones basadas en dirección
        // Aplicamos las mismas reglas para ambas direcciones para mayor consistencia
        if (currentScrollY > 80) {
            header.classList.add('scrolled', 'scrolled-complete');
            header.classList.remove('scrolled-start');
        } else if (currentScrollY > 30) {
            header.classList.add('scrolled-start');
            header.classList.remove('scrolled', 'scrolled-complete');
        } else {
            header.classList.remove('scrolled', 'scrolled-start', 'scrolled-complete');
        }
    };
    
    // Apply scroll handler with passive flag for better performance
    window.addEventListener('scroll', handleScroll, { passive: true });
    
    // Enhanced theme toggle with animation effects
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            // Add ripple effect class
            this.classList.add('clicked');
            
            // Toggle dark mode with slight delay for visual effect
            setTimeout(() => {
                document.body.classList.toggle('dark-mode');
                
                // Store user preference
                if (document.body.classList.contains('dark-mode')) {
                    localStorage.setItem('theme', 'dark');
                    
                    // Actualizado para reflejar el tema festivo
                    if (themeToggle.hasAttribute('role') && themeToggle.getAttribute('role') === 'switch') {
                        themeToggle.setAttribute('aria-checked', 'true');
                    }
                    
                    // Actualizado el texto para el lector de pantalla
                    const srOnly = themeToggle.querySelector('.sr-only');
                    if (srOnly) srOnly.textContent = 'Cambiar a tema predefinido';
                } else {
                    localStorage.setItem('theme', 'light');
                    
                    // Actualizado para reflejar el tema predefinido
                    if (themeToggle.hasAttribute('role') && themeToggle.getAttribute('role') === 'switch') {
                        themeToggle.setAttribute('aria-checked', 'false');
                    }
                    
                    // Actualizado el texto para el lector de pantalla
                    const srOnly = themeToggle.querySelector('.sr-only');
                    if (srOnly) srOnly.textContent = 'Cambiar a tema festivo';
                }
            }, 150);
            
            // Remove ripple class after animation completes
            setTimeout(() => {
                this.classList.remove('clicked');
            }, 600);
        });
    }
    
    // Improved mobile menu handling
    if (menuToggle && mobileMenu) {
        menuToggle.addEventListener('click', function() {
            menuIcon.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            
            // Toggle body scroll and add proper aria attributes
            if (mobileMenu.classList.contains('active')) {
                document.body.style.overflow = 'hidden';
                menuToggle.setAttribute('aria-expanded', 'true');
                mobileMenu.setAttribute('aria-hidden', 'false');
                
                // Actualizar indicador de scroll después de que el menú se abre
                setTimeout(updateScrollIndicator, 500);
            } else {
                document.body.style.overflow = '';
                menuToggle.setAttribute('aria-expanded', 'false');
                mobileMenu.setAttribute('aria-hidden', 'true');
            }
        });
    }
    
    // Enhanced menu closing functions
    function closeMobileMenu() {
        if (!menuIcon || !mobileMenu) return;
        
        menuIcon.classList.remove('active');
        mobileMenu.classList.remove('active');
        document.body.style.overflow = '';
        
        if (menuToggle) {
            menuToggle.setAttribute('aria-expanded', 'false');
        }
        
        if (mobileMenu) {
            mobileMenu.setAttribute('aria-hidden', 'true');
        }
    }
    
    // Close menu when clicking menu items
    const menuItemElements = document.querySelectorAll('.menu-item');
    menuItemElements.forEach(item => {
        item.addEventListener('click', closeMobileMenu);
        
        // Efecto táctil para elementos del menú
        item.addEventListener('touchstart', function() {
            this.style.transform = 'scale(0.98)';
            this.style.opacity = '0.9';
        });
        
        item.addEventListener('touchend', function() {
            setTimeout(() => {
                this.style.transform = '';
                this.style.opacity = '';
            }, 150);
        });
    });
    
    // Close menu when clicking overlay
    const mobileMenuOverlay = document.querySelector('.mobile-menu-overlay');
    if (mobileMenuOverlay) {
        mobileMenuOverlay.addEventListener('click', closeMobileMenu);
    }
    
    // Close menu on escape key press for accessibility
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && mobileMenu && mobileMenu.classList.contains('active')) {
            closeMobileMenu();
        }
    });
    
    // Smooth scrolling for navigation links with improved handling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            
            // Skip empty anchors
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                e.preventDefault();
                
                const headerHeight = header.offsetHeight;
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Update URL without page jump
                history.pushState(null, null, targetId);
            }
        });
    });
    
    // Add keyboard accessibility for interactive elements
    function setupKeyboardAccessibility() {
        // Make theme toggle keyboard accessible
        if (themeToggle && !themeToggle.hasAttribute('tabindex')) {
            themeToggle.setAttribute('tabindex', '0');
            themeToggle.setAttribute('role', 'switch');
            themeToggle.setAttribute('aria-checked', document.body.classList.contains('dark-mode') ? 'true' : 'false');
            
            // Add screen reader text if not present
            if (!themeToggle.querySelector('.sr-only')) {
                const srText = document.createElement('span');
                srText.className = 'sr-only';
                // Actualizado para reflejar los nuevos temas
                srText.textContent = document.body.classList.contains('dark-mode') ? 
                    'Cambiar a tema predefinido' : 'Cambiar a tema festivo';
                themeToggle.prepend(srText);
            }
            
            // Handle keyboard activation
            themeToggle.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.click();
                }
            });
        }
    }
    
    // Initialize accessibility enhancements
    setupKeyboardAccessibility();
    
    // Función para verificar si es necesario mostrar el indicador de scroll para el menú móvil
    function updateScrollIndicator() {
        if (!mobileMenuItems) return;
        
        // Determinar si estamos en modo paisaje
        const isLandscape = window.matchMedia("(orientation: landscape)").matches && window.innerHeight <= 450;
        
        if (isLandscape) {
            // Modo horizontal (paisaje)
            const scrollWidth = mobileMenuItems.scrollWidth;
            const clientWidth = mobileMenuItems.clientWidth;
            
            if (scrollWidth > clientWidth + 5) { // Agregamos un pequeño umbral
                mobileMenuItems.classList.add('scrollable');
                
                // Verificar si hemos llegado al final del scroll
                if (mobileMenuItems.scrollLeft + clientWidth >= scrollWidth - 20) {
                    mobileMenuItems.classList.remove('scrollable');
                }
            } else {
                mobileMenuItems.classList.remove('scrollable');
            }
        } else {
            // Modo vertical (retrato)
            const scrollHeight = mobileMenuItems.scrollHeight;
            const clientHeight = mobileMenuItems.clientHeight;
            
            if (scrollHeight > clientHeight + 20) { // Umbral más grande para modo vertical
                mobileMenuItems.classList.add('scrollable');
                
                // Verificar si hemos llegado al final del scroll
                if (mobileMenuItems.scrollTop + clientHeight >= scrollHeight - 60) {
                    mobileMenuItems.classList.remove('scrollable');
                }
            } else {
                mobileMenuItems.classList.remove('scrollable');
            }
        }
    }
    
    // Configurar eventos de scroll para el menú móvil
    if (mobileMenuItems) {
        // Actualizar indicador en eventos de scroll
        mobileMenuItems.addEventListener('scroll', updateScrollIndicator);
        
        // Actualizar en cambio de orientación o redimensión
        window.addEventListener('resize', function() {
            setTimeout(updateScrollIndicator, 300);
        });
        
        window.addEventListener('orientationchange', function() {
            setTimeout(updateScrollIndicator, 300);
        });
        
        // Forzar una actualización inicial
        setTimeout(updateScrollIndicator, 500);
        
        // También actualizar después de que todo esté cargado
        window.addEventListener('load', function() {
            setTimeout(updateScrollIndicator, 1000);
        });
    }
});

// 2. GALERÍA
// Seleccionar todos los enlaces a Galería (tanto en desktop como en móvil)
document.addEventListener('DOMContentLoaded', function() {
    const galeriaLinks = document.querySelectorAll('.nav-desktop .nav-links li a[href="#galeria"], .mobile-menu-items a[href="#galeria"]');

    galeriaLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = 'galeria.html';
        });
    });

    // Cerrar el menú móvil después de hacer clic en cualquier enlace
    function closeMobileMenu() {
        const mobileMenu = document.querySelector('.mobile-menu');
        if (mobileMenu && mobileMenu.classList.contains('active')) {
            setTimeout(() => {
                mobileMenu.classList.remove('active');
                document.body.classList.remove('menu-open');
            }, 100);
        }
    }

    // Añadir evento de cierre del menú móvil a todos los enlaces
    const allHeaderLinks = document.querySelectorAll('.nav-desktop .nav-links li a, .mobile-menu-items a');
    allHeaderLinks.forEach(link => {
        link.addEventListener('click', closeMobileMenu);
    });

    // 4. LOGO DEL HEADER
    // Hacer que tanto el icono como el nombre en el logo redirijan a index.html
    const headerLogo = document.querySelector('.logo-container');
    if (headerLogo) {
        headerLogo.style.cursor = 'pointer';
        headerLogo.addEventListener('click', function() {
            window.location.href = 'index.html';
        });
    }

    // También se puede hacer clic directamente en el logo o el nombre
    const logoIcon = document.querySelector('.logo-icon');
    const logoName = document.querySelector('.logo-name');

    if (logoIcon) {
        logoIcon.style.cursor = 'pointer';
        logoIcon.addEventListener('click', function(e) {
            e.stopPropagation(); // Evitar doble redirección si el contenedor padre también tiene listener
            window.location.href = 'index.html';
        });
    }

    if (logoName) {
        logoName.style.cursor = 'pointer';
        logoName.addEventListener('click', function(e) {
            e.stopPropagation(); // Evitar doble redirección
            window.location.href = 'index.html';
        });
    }

    // 5. LOGO DEL FOOTER
    // Hacer que el logo del footer redirija a index.html
    const footerLogo = document.querySelector('.footer-logo');
    if (footerLogo) {
        footerLogo.style.cursor = 'pointer';
        footerLogo.addEventListener('click', function() {
            window.location.href = 'index.html';
        });
    }
});

// ======= FUNCIÓN PARA INICIALIZAR EL ACORDEÓN DE FAQ Y ANIMACIONES DE SECCIONES =======
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar el acordeón FAQ
    initFaqAccordion();
    
    // Inicializar la detección de visibilidad de secciones
    checkVisibility();
    window.addEventListener('scroll', checkVisibility);
    window.addEventListener('resize', checkVisibility);
});

// Función para detectar y animar las secciones al hacerse visibles
function checkVisibility() {
    const sections = document.querySelectorAll('.faq-section, .about-section, .offerings-section, .location-section');
    
    sections.forEach(section => {
        const sectionTop = section.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
        
        if (sectionTop < windowHeight * 0.75) {
            section.classList.add('section-visible');
        }
    });
}

// Inicialización del acordeón FAQ
function initFaqAccordion() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    if (!faqItems.length) return;
    
    // Añadir listeners a cada pregunta
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        if (question) {
            question.addEventListener('click', () => {
                // Si ya está activo, solo ciérralo
                if (item.classList.contains('active')) {
                    item.classList.remove('active');
                    return;
                }
                
                // Cerrar todos los items abiertos
                faqItems.forEach(otherItem => {
                    if (otherItem !== item && otherItem.classList.contains('active')) {
                        otherItem.classList.remove('active');
                    }
                });
                
                // Abrir el item actual
                item.classList.add('active');
            });
        }
    });
}