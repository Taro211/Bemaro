document.addEventListener('DOMContentLoaded', function() {
    // Animación de secciones al hacer scroll
    const contactSection = document.querySelector('.location-contact-section');
    
    if (contactSection) {
        // Verificar soporte para IntersectionObserver
        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('section-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1 });
            
            observer.observe(contactSection);
        } else {
            // Fallback para navegadores sin soporte
            contactSection.classList.add('section-visible');
        }
    }
});