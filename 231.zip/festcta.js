/**
 * festcta.js - Efectos de globos para secciones CTA
 * Añade globos flotantes a las secciones CTA con correcto z-index
 * Modificado para mostrar globos solo en modo festivo (clase dark-mode)
 */

document.addEventListener('DOMContentLoaded', function() {
    // Variables de control
    let isActive = false;
    let activeBalloons = [];
    const MAX_BALLOONS = 10; // Máximo de globos en sección CTA
    let lastCreationTime = 0;
    const MIN_CREATION_INTERVAL = 100; // Tiempo mínimo entre creaciones (ms)
    let animationCheckTimer = null;

    // Verificar si estamos en una página con sección CTA
    const hasCTASection = document.querySelector('.cta-section') !== null;
    console.log("Sección CTA encontrada:", hasCTASection);
    
    if (!hasCTASection) {
        console.log("No se encontró sección CTA en esta página. El script festcta.js no se ejecutará.");
        return; // Terminar ejecución si no hay sección CTA
    }

    // Crear y añadir un globo al DOM
    const createBalloon = () => {
        // Control de frecuencia de creación
        const now = Date.now();
        if (now - lastCreationTime < MIN_CREATION_INTERVAL) return;
        lastCreationTime = now;
        
        // Obtener sección CTA
        const container = document.querySelector('.cta-section');
        if (!container || !isActive || activeBalloons.length >= MAX_BALLOONS) return;
        
        // Seleccionar tipo de globo
        const types = ['purple', 'blue', 'orange'];
        const type = types[Math.floor(Math.random() * types.length)];
        
        // Crear elemento globo
        const balloon = document.createElement('div');
        balloon.className = `cta-balloon balloon-${type}`;
        
        // Posición horizontal aleatoria
        balloon.style.left = `${5 + Math.random() * 90}%`;
        
        // Escala con variación aleatoria según tipo
        const baseScale = {
            'purple': 1,
            'blue': 0.85,
            'orange': 1.15
        }[type];
        
        // Añadir variación a la escala (±15%)
        const scaleVariation = 0.85 + (Math.random() * 0.3);
        const finalScale = baseScale * scaleVariation;
        
        // Duración de animación aleatoria (5-10 segundos)
        const animationDuration = 5 + Math.random() * 5;
        
        // Aplicar propiedades visuales con transición de opacidad - Sin z-index aquí
        Object.assign(balloon.style, {
            transform: `scale(${finalScale})`,
            opacity: '0', // Iniciar invisible para fadeIn
            transition: 'opacity 0.8s ease',
            animationDuration: `${animationDuration}s`,
            animationDelay: `${Math.random() * 0.5}s`,
            animationTimingFunction: 'linear',
            animationFillMode: 'forwards',
            animationName: `ctaBalloonFloat${Math.floor(Math.random() * 5) + 1}`
        });
        
        // Añadir al DOM
        container.appendChild(balloon);
        
        // Forzar reflow antes de cambiar opacidad
        void balloon.offsetWidth;
        
        // Hacer visible con transición - opacidad variable
        balloon.style.opacity = `${0.5 + Math.random() * 0.3}`; // Entre 0.5 y 0.8
        
        // Registrar globo activo
        const balloonInfo = {
            element: balloon,
            endTime: Date.now() + (animationDuration * 1000),
            created: Date.now()
        };
        
        activeBalloons.push(balloonInfo);
        
        // Programar eliminación
        setTimeout(() => {
            if (balloon.parentNode) {
                // Aplicar fadeOut antes de eliminar
                balloon.style.opacity = '0';
                
                // Eliminar después de transición
                setTimeout(() => {
                    if (balloon.parentNode) {
                        balloon.parentNode.removeChild(balloon);
                        // Eliminar de lista activa
                        activeBalloons = activeBalloons.filter(item => item.element !== balloon);
                        
                        // Crear reemplazo con retraso aleatorio si sigue activo
                        if (isActive && Math.random() > 0.3) { // 70% probabilidad de reemplazo
                            setTimeout(createBalloon, Math.random() * 1500);
                        }
                    }
                }, 800);
            }
        }, animationDuration * 1000);
    };
    
    // Configurar animaciones CSS una sola vez
    const setupAnimations = () => {
        if (document.getElementById('cta-balloons-style')) return;
        
        const style = document.createElement('style');
        style.id = 'cta-balloons-style';
        
        // Crear múltiples variaciones de animación de globos
        let keyframesAll = '';
        for (let i = 1; i <= 5; i++) {
            // Valores aleatorios diferentes para cada keyframe
            const endX = [(-20 - i * 5), (20 + i * 5), (-5 * i), (5 * i), 0][i-1];
            const midX1 = endX * 0.3;
            const midX2 = endX * 0.7;
            
            keyframesAll += `
            @keyframes ctaBalloonFloat${i} {
                0% { transform: translateY(0) translateX(0) scale(${0.9 + Math.random() * 0.2}); }
                25% { transform: translateY(-150px) translateX(${midX1}px) scale(${0.9 + Math.random() * 0.2}); }
                75% { transform: translateY(-450px) translateX(${midX2}px) scale(${0.9 + Math.random() * 0.2}); }
                100% { transform: translateY(-650px) translateX(${endX}px) scale(${0.9 + Math.random() * 0.2}); opacity: 0; }
            }`;
        }
        
        // Estilos base para los globos - MODIFICADO z-index a 0
        style.textContent = `
            .cta-balloon {
                position: absolute;
                bottom: -100px;
                width: 50px;
                height: 70px;
                background-size: contain;
                background-repeat: no-repeat;
                pointer-events: none;
                transform: translateZ(0);
                backface-visibility: hidden;
                will-change: transform, opacity;
                transform-origin: center bottom;
                z-index: 0; /* MODIFICADO: Asegurar que los globos están detrás del contenido pero visibles */
                filter: blur(0.5px);
            }
            
            /* Asegurar que el contenido permanece por encima de los globos */
            .cta-content, .cta-section h2, .cta-section p, .cta-main-button {
                position: relative;
                z-index: 2; /* Aumentado para garantizar que esté por encima */
            }
            
            .balloon-purple {
                background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='70' viewBox='0 0 50 70'%3E%3Cpath d='M25,10 C32,10 38,16 38,25 C38,34 32,40 25,40 C18,40 12,34 12,25 C12,16 18,10 25,10 Z M23,41 L27,41 L27,55 L23,55 Z M23,55 C23,55 18,65 25,65 C32,65 27,55 27,55 Z' fill='%23AF539A'/%3E%3C/svg%3E");
            }
            
            .balloon-blue {
                background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='70' viewBox='0 0 50 70'%3E%3Cpath d='M25,10 C32,10 38,16 38,25 C38,34 32,40 25,40 C18,40 12,34 12,25 C12,16 18,10 25,10 Z M23,41 L27,41 L27,55 L23,55 Z M23,55 C23,55 18,65 25,65 C32,65 27,55 27,55 Z' fill='%2369B5CC'/%3E%3C/svg%3E");
            }
            
            .balloon-orange {
                background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='70' viewBox='0 0 50 70'%3E%3Cpath d='M25,10 C32,10 38,16 38,25 C38,34 32,40 25,40 C18,40 12,34 12,25 C12,16 18,10 25,10 Z M23,41 L27,41 L27,55 L23,55 Z M23,55 C23,55 18,65 25,65 C32,65 27,55 27,55 Z' fill='%23FF9933'/%3E%3C/svg%3E");
            }
            
            /* Añadir keyframes de animación */
            ${keyframesAll}

            /* Ajuste específico para la sección CTA en habitaciones.html */
            .cta-section {
                position: relative;
                overflow: hidden;
            }
        `;
        
        document.head.appendChild(style);
    };
    
    // Sistema de creación aleatorizada de globos
    const scheduleRandomBalloons = () => {
        if (!isActive) return;
        
        // ¿Cuántos globos podemos añadir?
        const available = MAX_BALLOONS - activeBalloons.length;
        
        if (available > 0) {
            // Número aleatorio a crear (1-2 globos, pero no más de los disponibles)
            const count = Math.min(Math.ceil(Math.random() * 2), available);
            
            // Crear con intervalos aleatorios
            for (let i = 0; i < count; i++) {
                setTimeout(createBalloon, Math.random() * 700);
            }
        }
        
        // Programar próxima verificación con tiempo aleatorio
        if (isActive) {
            animationCheckTimer = setTimeout(scheduleRandomBalloons, 800 + Math.random() * 1200);
        }
    };
    
    // Iniciar el efecto de globos
    const startBalloons = () => {
        if (isActive) return;
        
        isActive = true;
        console.log("Iniciando globos en sección CTA");
        
        // Eliminar globos existentes con efecto de desvanecimiento
        document.querySelectorAll('.cta-balloon').forEach(el => {
            if (el.parentNode) {
                el.style.opacity = '0';
                setTimeout(() => {
                    if (el.parentNode) el.parentNode.removeChild(el);
                }, 800);
            }
        });
        
        // Reiniciar seguimiento de globos
        activeBalloons = [];
        
        // Configurar animaciones CSS
        setupAnimations();
        
        // Crear globos iniciales - cantidad aleatoria
        const initialBalloons = 3 + Math.floor(Math.random() * 3); // Entre 3 y 5 globos iniciales
        
        for (let i = 0; i < initialBalloons; i++) {
            // Tiempos de creación aleatorios entre 0 y 2 segundos
            setTimeout(createBalloon, Math.random() * 2000);
        }
        
        // Iniciar sistema aleatorizado
        setTimeout(scheduleRandomBalloons, 2000);
    };
    
    // Detener el efecto de globos con desvanecimiento
    const stopBalloons = () => {
        isActive = false;
        console.log("Deteniendo globos en sección CTA");
        
        // Cancelar verificaciones programadas
        if (animationCheckTimer) {
            clearTimeout(animationCheckTimer);
            animationCheckTimer = null;
        }
        
        // Aplicar desvanecimiento a todos los globos existentes con tiempo aleatorio
        const balloons = document.querySelectorAll('.cta-balloon');
        
        balloons.forEach(balloon => {
            // Tiempo aleatorio para inicio de desvanecimiento (máx 800ms)
            setTimeout(() => {
                balloon.style.opacity = '0';
                
                // Eliminar después de completar transición
                setTimeout(() => {
                    if (balloon.parentNode) {
                        balloon.parentNode.removeChild(balloon);
                    }
                }, 800);
            }, Math.random() * 800);
        });
        
        // Limpiar array de seguimiento
        activeBalloons = [];
    };
    
    // Verificar modo festivo y gestionar globos
    const checkFestiveMode = () => {
        // Solo mostrar globos cuando el body tiene clase dark-mode (modo festivo)
        const isFestiveMode = document.body.classList.contains('dark-mode');
        
        if (isFestiveMode && !isActive) {
            startBalloons();
        } else if (!isFestiveMode && isActive) {
            stopBalloons();
        }
    };
    
    // Verificación inicial de modo festivo
    setTimeout(checkFestiveMode, 500); // Aumentado el tiempo para asegurar que todo esté cargado
    
    // Observar cambios en modo festivo
    const observer = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            if (mutation.attributeName === 'class') {
                setTimeout(checkFestiveMode, 100); // Pequeño retraso para evitar problemas de sincronización
            }
        });
    });
    
    observer.observe(document.body, { attributes: true });
    
    // Limpiar al salir de la página
    window.addEventListener('beforeunload', () => {
        observer.disconnect();
        if (animationCheckTimer) clearTimeout(animationCheckTimer);
        isActive = false;
    });
});