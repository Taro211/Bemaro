document.addEventListener('DOMContentLoaded', function() {
    // Inicializar los componentes específicos de la página
    // NO inicializamos el FAQ aquí, ya lo hace el script global
    initAnimations();
    initFilterButtons();
    initScrollEffects();
    
    // Remover cualquier splash screen residual si existe
    const splashScreen = document.querySelector('.splash-screen');
    if (splashScreen) {
        splashScreen.remove();
    }
});

// ELIMINAMOS la función initFaqAccordion para evitar conflictos con el script global

// Inicializar animaciones de la página
function initAnimations() {
    // Animar las categorías de actividades al hacer scroll
    const categorias = document.querySelectorAll('.actividad-categoria');
    
    // Verificar soporte para IntersectionObserver
    if ('IntersectionObserver' in window) {
        const categoryObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                    
                    // También aplicar animaciones a los elementos internos
                    const elements = entry.target.querySelectorAll('.actividad-card');
                    elements.forEach((el, index) => {
                        el.style.transitionDelay = `${index * 0.1 + 0.2}s`;
                        el.style.opacity = '1';
                        el.style.transform = 'translateY(0)';
                    });
                    
                    // Dejar de observar este elemento
                    categoryObserver.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.15,
            rootMargin: '0px 0px -100px 0px'
        });
        
        // Observar las categorías
        categorias.forEach(categoria => {
            // Inicializar estilo para animación
            categoria.style.opacity = '0';
            categoria.style.transform = 'translateY(30px)';
            categoria.style.transition = 'opacity 0.7s ease-out, transform 0.7s cubic-bezier(0.34, 1.56, 0.64, 1)';
            
            // Configurar tarjetas internas para animación
            const cards = categoria.querySelectorAll('.actividad-card');
            cards.forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(30px)';
                card.style.transition = 'opacity 0.6s ease-out, transform 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)';
            });
            
            categoryObserver.observe(categoria);
        });
    } else {
        // Fallback para navegadores sin soporte para IntersectionObserver
        categorias.forEach(categoria => {
            categoria.style.opacity = '1';
            categoria.style.transform = 'translateY(0)';
            
            const cards = categoria.querySelectorAll('.actividad-card');
            cards.forEach(card => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            });
        });
    }
    
    // Animación para la sección CTA
    const ctaSection = document.querySelector('.cta-section');
    if (ctaSection) {
        // Aplicar la misma animación que en el index
        if ('IntersectionObserver' in window) {
            const ctaObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        // Añadir la clase section-visible como en index.js
                        entry.target.classList.add('section-visible');
                        ctaObserver.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.3
            });
            
            // Agregar clase para la animación igual que en index.js
            ctaSection.classList.add('section-hidden');
            ctaObserver.observe(ctaSection);
        } else {
            // Fallback para navegadores sin soporte para IntersectionObserver
            ctaSection.classList.add('section-visible');
        }
    }
}

// Inicializar filtros de categorías si existen
function initFilterButtons() {
    const filterButtons = document.querySelectorAll('.filter-button');
    const categorias = document.querySelectorAll('.actividad-categoria');
    
    if (filterButtons.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Remover clase activa de todos los botones
                filterButtons.forEach(btn => btn.classList.remove('active'));
                
                // Añadir clase activa al botón actual
                button.classList.add('active');
                
                // Filtrar categorías
                const filter = button.getAttribute('data-filter');
                
                if (filter === 'all') {
                    // Mostrar todas las categorías
                    categorias.forEach(cat => {
                        cat.style.display = 'block';
                        
                        // Reactivar animaciones
                        setTimeout(() => {
                            cat.style.opacity = '1';
                            cat.style.transform = 'translateY(0)';
                        }, 100);
                    });
                } else {
                    // Mostrar solo la categoría seleccionada
                    categorias.forEach(cat => {
                        if (cat.id === filter) {
                            cat.style.display = 'block';
                            
                            // Reactivar animaciones
                            setTimeout(() => {
                                cat.style.opacity = '1';
                                cat.style.transform = 'translateY(0)';
                            }, 100);
                        } else {
                            cat.style.display = 'none';
                        }
                    });
                }
            });
        });
    }
}

// Inicializar efectos de scroll
function initScrollEffects() {
    // Smooth scroll para enlaces internos
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            // Verificar que el href no esté vacío y el elemento exista
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                e.preventDefault();
                
                // Calcular offset considerando el header
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Si estamos en móvil, cerrar el menú
                const mobileMenu = document.querySelector('.mobile-menu');
                const menuIcon = document.querySelector('.menu-icon');
                
                if (mobileMenu && mobileMenu.classList.contains('active')) {
                    mobileMenu.classList.remove('active');
                    if (menuIcon) menuIcon.classList.remove('active');
                    document.body.style.overflow = '';
                }
            }
        });
    });
    
    // Animación para la sección de contacto - VERSIÓN EDITADA
    const contactSection = document.querySelector('.location-contact-section');
    
    if (contactSection) {
        // Verificar si ya tiene clase visible (aplicada por otro script)
        if (!contactSection.classList.contains('section-visible')) {
            // Solo aplicar animación si no ha sido animada por otro script
            if ('IntersectionObserver' in window) {
                const observer = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            // Marcar como visible
                            entry.target.classList.add('section-visible');
                            // Eliminar la clase section-hidden si existe
                            entry.target.classList.remove('section-hidden');
                            observer.unobserve(entry.target);
                        }
                    });
                }, { threshold: 0.1 });
                
                observer.observe(contactSection);
            } else {
                // Fallback para navegadores sin soporte
                contactSection.classList.add('section-visible');
                contactSection.classList.remove('section-hidden');
            }
        }
    }
    
    // Efecto parallax sutil en el hero
    const heroSection = document.querySelector('.actividades-hero');
    if (heroSection) {
        window.addEventListener('scroll', function() {
            const scrollPosition = window.scrollY;
            if (scrollPosition < 600) {
                const translateY = scrollPosition * 0.3;
                heroSection.style.backgroundPosition = `center ${translateY}px`;
            }
        });
    }
}

// Código adicional para asegurar que la sección de contacto sea visible
document.addEventListener('DOMContentLoaded', function() {
    // Asegurarnos que la sección de contacto sea visible
    const contactSection = document.querySelector('.location-contact-section');
    
    if (contactSection) {
        // Comprobar si la sección tiene la clase section-hidden
        if (contactSection.classList.contains('section-hidden') || 
            getComputedStyle(contactSection).opacity === '0') {
            
            // Si hay problema de visibilidad, forzar la visibilidad
            setTimeout(function() {
                contactSection.classList.add('section-visible');
                contactSection.classList.remove('section-hidden');
                contactSection.style.opacity = '1';
                contactSection.style.transform = 'translateY(0)';
            }, 500);
        }
    }
});