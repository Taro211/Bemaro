/**
 * fest.js - Solución optimizada con generación aleatoria
 * 16 globos con aparición randomizada y desvanecimiento suave
 */

document.addEventListener('DOMContentLoaded', function() {
    // Control principal
    let isActive = false;
    let activeGlobos = [];
    const MAX_GLOBOS = 16; // Mantener 16 máximo
    let lastCreationTime = 0; // Control de tiempo para randomizar creación
    const MIN_CREATION_INTERVAL = 100; // Tiempo mínimo entre creaciones (ms)
    
    // Función para generar un globo y añadirlo al DOM
    const crearGlobo = () => {
        // Control de frecuencia de creación
        const now = Date.now();
        if (now - lastCreationTime < MIN_CREATION_INTERVAL) return;
        lastCreationTime = now;
        
        // Si ya hay suficientes globos, no crear más
        if (activeGlobos.length >= MAX_GLOBOS || !isActive) return;
        
        const container = document.querySelector('.welcome-left');
        if (!container) return;
        
        // Seleccionar tipo de globo
        const tipos = ['purple', 'blue', 'orange'];
        const tipo = tipos[Math.floor(Math.random() * tipos.length)];
        
        // Crear elemento
        const globo = document.createElement('div');
        globo.className = `festive-balloon balloon-${tipo}`;
        
        // Posición horizontal completamente aleatoria
        globo.style.left = `${5 + Math.random() * 90}%`;
        
        // Escala con variación aleatoria
        const baseScale = {
            'purple': 1,
            'blue': 0.85,
            'orange': 1.15
        }[tipo];
        
        // Añadir variación a la escala (±15%)
        const scaleVariation = 0.85 + (Math.random() * 0.3); // Entre 0.85 y 1.15
        const finalScale = baseScale * scaleVariation;
        
        // Duración más variable: 5-10 segundos
        const animationDuration = 5 + Math.random() * 5;
        
        // Config visual con transición para opacidad
        Object.assign(globo.style, {
            transform: `scale(${finalScale})`,
            opacity: '0', // Iniciar invisible para fadeIn
            zIndex: `${Math.floor(Math.random() * 3) + 1}`, // Z-index aleatorio para efecto de profundidad
            transition: 'opacity 0.8s ease', // Transición para fundido
            animationDuration: `${animationDuration}s`,
            animationDelay: `${Math.random() * 0.5}s`, // Pequeño delay aleatorio para inicio
            animationTimingFunction: 'linear',
            animationFillMode: 'forwards',
            animationName: `globoFloat${Math.floor(Math.random() * 5) + 1}` // Más variaciones de animación
        });
        
        // Añadir al DOM
        container.appendChild(globo);
        
        // Forzar reflow antes de cambiar la opacidad
        void globo.offsetWidth;
        
        // Hacer visible con transición - opacidad variable
        globo.style.opacity = `${0.5 + Math.random() * 0.3}`; // Entre 0.5 y 0.8
        
        // Registrar globo activo
        activeGlobos.push({
            element: globo,
            endTime: Date.now() + (animationDuration * 1000),
            created: Date.now() // Registrar cuando fue creado
        });
        
        // Programar eliminación
        setTimeout(() => {
            if (globo.parentNode) {
                // Aplicar fadeOut antes de eliminar
                globo.style.opacity = '0';
                
                // Eliminar después de la transición
                setTimeout(() => {
                    if (globo.parentNode) {
                        globo.parentNode.removeChild(globo);
                        // Eliminar de la lista de activos
                        activeGlobos = activeGlobos.filter(item => item.element !== globo);
                        
                        // Programar creación de reemplazo con tiempo aleatorio
                        if (isActive && Math.random() > 0.3) { // 70% de probabilidad de reemplazo inmediato
                            setTimeout(crearGlobo, Math.random() * 1500); // Entre 0 y 1.5 segundos
                        }
                    }
                }, 800);
            }
        }, animationDuration * 1000);
    };
    
    // Función para establecer animaciones CSS una sola vez
    const setupAnimaciones = () => {
        if (document.getElementById('globos-style')) return;
        
        const style = document.createElement('style');
        style.id = 'globos-style';
        
        // Más variaciones de animaciones para mayor randomización
        let keyframesAll = '';
        for (let i = 1; i <= 5; i++) {
            // Valores aleatorios predefinidos pero diferentes para cada keyframe
            const endX = [(-20 - i * 5), (20 + i * 5), (-5 * i), (5 * i), 0][i-1];
            const midX1 = endX * 0.3;
            const midX2 = endX * 0.7;
            
            keyframesAll += `
            @keyframes globoFloat${i} {
                0% { transform: translateY(0) translateX(0); }
                25% { transform: translateY(-150px) translateX(${midX1}px); }
                75% { transform: translateY(-450px) translateX(${midX2}px); }
                100% { transform: translateY(-650px) translateX(${endX}px); opacity: 0; }
            }`;
        }
        
        // Estilos básicos y todas las variaciones de animación
        style.textContent = `
            .festive-balloon {
                position: absolute;
                bottom: -100px;
                width: 50px;
                height: 70px;
                background-size: contain;
                background-repeat: no-repeat;
                pointer-events: none;
                transform: translateZ(0);
                backface-visibility: hidden;
                will-change: transform, opacity;
                transform-origin: center bottom;
            }
            
            .balloon-purple {
                background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='70' viewBox='0 0 50 70'%3E%3Cpath d='M25,10 C32,10 38,16 38,25 C38,34 32,40 25,40 C18,40 12,34 12,25 C12,16 18,10 25,10 Z M23,41 L27,41 L27,55 L23,55 Z M23,55 C23,55 18,65 25,65 C32,65 27,55 27,55 Z' fill='%23AF539A'/%3E%3C/svg%3E");
            }
            
            .balloon-blue {
                background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='70' viewBox='0 0 50 70'%3E%3Cpath d='M25,10 C32,10 38,16 38,25 C38,34 32,40 25,40 C18,40 12,34 12,25 C12,16 18,10 25,10 Z M23,41 L27,41 L27,55 L23,55 Z M23,55 C23,55 18,65 25,65 C32,65 27,55 27,55 Z' fill='%2369B5CC'/%3E%3C/svg%3E");
            }
            
            .balloon-orange {
                background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='70' viewBox='0 0 50 70'%3E%3Cpath d='M25,10 C32,10 38,16 38,25 C38,34 32,40 25,40 C18,40 12,34 12,25 C12,16 18,10 25,10 Z M23,41 L27,41 L27,55 L23,55 Z M23,55 C23,55 18,65 25,65 C32,65 27,55 27,55 Z' fill='%23FF9933'/%3E%3C/svg%3E");
            }
            
            ${keyframesAll}
        `;
        
        document.head.appendChild(style);
    };
    
    // Sistema optimizado para creación aleatoria
    let nextCheck = null;
    
    const randomizarCreacion = () => {
        if (!isActive) return;
        
        // Verificar cuántos faltarían para llegar al máximo
        const faltantes = MAX_GLOBOS - activeGlobos.length;
        
        if (faltantes > 0) {
            // Cantidad aleatoria a crear (entre 1 y faltantes, pero no más de 2)
            const cantidad = Math.min(Math.ceil(Math.random() * 2), faltantes);
            
            // Crear con intervalos aleatorios
            for (let i = 0; i < cantidad; i++) {
                setTimeout(crearGlobo, Math.random() * 700);
            }
        }
        
        // Programar próxima verificación con tiempo aleatorio
        // para evitar patrones predecibles
        if (isActive) {
            nextCheck = setTimeout(randomizarCreacion, 800 + Math.random() * 1200); // Entre 0.8s y 2s
        }
    };
    
    // Iniciar efecto con distribución aleatoria
    const iniciar = () => {
        if (isActive) return;
        
        isActive = true;
        console.log('Modo festivo activado: generación randomizada');
        
        // Limpiar globos existentes con efecto de desvanecimiento
        document.querySelectorAll('.festive-balloon').forEach(el => {
            if (el.parentNode) {
                el.style.opacity = '0';
                setTimeout(() => {
                    if (el.parentNode) el.parentNode.removeChild(el);
                }, 800);
            }
        });
        
        activeGlobos = [];
        
        // Establecer animaciones CSS
        setupAnimaciones();
        
        // Crear globos iniciales - completamente randomizados
        const globosIniciales = 4 + Math.floor(Math.random() * 4); // Entre 4 y 7 globos iniciales
        
        for (let i = 0; i < globosIniciales; i++) {
            // Tiempos completamente aleatorios entre 0 y 2 segundos
            setTimeout(crearGlobo, Math.random() * 2000);
        }
        
        // Iniciar sistema randomizado
        setTimeout(randomizarCreacion, 2000);
    };
    
    // Función para detener con desvanecimiento aleatorio
    const detener = () => {
        isActive = false;
        console.log('Modo festivo desactivado');
        
        // Cancelar próxima verificación si existe
        if (nextCheck) {
            clearTimeout(nextCheck);
            nextCheck = null;
        }
        
        // Aplicar desvanecimiento a todos los globos existentes con tiempos aleatorios
        const globos = document.querySelectorAll('.festive-balloon');
        
        globos.forEach(globo => {
            // Tiempo aleatorio para inicio de desvanecimiento (máximo 800ms)
            setTimeout(() => {
                // Aplicar transición de desvanecimiento
                globo.style.opacity = '0';
                
                // Eliminar después de completar la transición
                setTimeout(() => {
                    if (globo.parentNode) {
                        globo.parentNode.removeChild(globo);
                    }
                }, 800);
            }, Math.random() * 800);
        });
        
        // Limpiar array de control
        activeGlobos = [];
    };
    
    // Estado inicial
    if (document.body.classList.contains('dark-mode')) {
        setTimeout(iniciar, 1000);
    }
    
    // Observar cambios de modo
    const observer = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            if (mutation.attributeName === 'class') {
                const isDarkMode = document.body.classList.contains('dark-mode');
                if (isDarkMode) {
                    iniciar();
                } else {
                    detener();
                }
            }
        });
    });
    
    observer.observe(document.body, { attributes: true });
    
    // Limpiar al salir
    window.addEventListener('beforeunload', () => {
        observer.disconnect();
        if (nextCheck) clearTimeout(nextCheck);
        isActive = false;
    });
    
    // Ajustar para cambios de tamaño
    let resizeTimer;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            if (document.body.classList.contains('dark-mode')) {
                detener();
                setTimeout(iniciar, 1000);
            }
        }, 500);
    });
});


