// Script simplificado que solo maneja bienvenida, galería y animaciones
document.addEventListener('DOMContentLoaded', function() {
    // Iniciar solo los componentes requeridos
    initWelcomeCarousel();
    initGalleryCarousel();
    initPageEffects();
    enhanceGalleryForMobile();
    enhanceWelcomeResponsiveness();
});

// ======= CARRUSEL DE BIENVENIDA MEJORADO =======
function initWelcomeCarousel() {
    // Elementos del carrusel
    const carousel = document.querySelector('.carousel');
    if (!carousel) return;
    
    const carouselItems = document.querySelectorAll('.carousel-item');
    const prevButton = document.querySelector('.carousel-control.prev');
    const nextButton = document.querySelector('.carousel-control.next');
    const indicators = document.querySelectorAll('.indicator');
    
    if (carouselItems.length === 0) return;
    
    let currentSlide = 0;
    let interval;
    let pauseOnHover = true;
    
    // Función para mostrar una diapositiva específica
    const showSlide = (index) => {
        // Comprobar si el índice está dentro de los límites
        if (index < 0) index = carouselItems.length - 1;
        if (index >= carouselItems.length) index = 0;
        
        // Remover la clase 'active' de todas las diapositivas
        carouselItems.forEach(item => {
            item.classList.remove('active');
        });
        
        // Remover la clase 'active' de todos los indicadores
        indicators.forEach(indicator => {
            indicator.classList.remove('active');
        });
        
        // Añadir la clase 'active' a la diapositiva actual
        carouselItems[index].classList.add('active');
        
        // Añadir la clase 'active' al indicador actual
        if (indicators.length > 0 && index < indicators.length) {
            indicators[index].classList.add('active');
        }
        
        // Animar la entrada de las leyendas con un pequeño retraso
        setTimeout(() => {
            const captions = document.querySelectorAll('.carousel-caption');
            captions.forEach((caption, i) => {
                if (i === index) {
                    caption.style.opacity = '1';
                    caption.style.transform = 'translate(-50%, -15px)';
                } else {
                    caption.style.opacity = '0';
                    caption.style.transform = 'translate(-50%, 10px)';
                }
            });
        }, 300);
        
        // Actualizar el índice de la diapositiva actual
        currentSlide = index;
    };
    
    // Función para la diapositiva siguiente
    const nextSlide = () => {
        showSlide(currentSlide + 1);
    };
    
    // Función para la diapositiva anterior
    const prevSlide = () => {
        showSlide(currentSlide - 1);
    };
    
    // Iniciar el carrusel automático
    const startCarousel = () => {
        // Limpiar cualquier intervalo existente primero
        stopCarousel();
        interval = setInterval(nextSlide, 5000); // Cambiar cada 5 segundos
    };
    
    // Detener el carrusel automático
    const stopCarousel = () => {
        clearInterval(interval);
    };
    
    // Reiniciar el carrusel (detener y luego iniciar)
    const resetCarousel = () => {
        stopCarousel();
        startCarousel();
    };
    
    // Event listeners para los botones de navegación
    if (prevButton && nextButton) {
        prevButton.addEventListener('click', () => {
            prevSlide();
            resetCarousel();
        });
        
        nextButton.addEventListener('click', () => {
            nextSlide();
            resetCarousel();
        });
    }
    
    // Event listeners para los indicadores
    if (indicators.length > 0) {
        indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => {
                showSlide(index);
                resetCarousel();
            });
        });
    }
    
    // Pausar el carrusel al pasar el mouse sobre él
    if (carousel && pauseOnHover) {
        carousel.addEventListener('mouseenter', stopCarousel);
        carousel.addEventListener('mouseleave', startCarousel);
    }
    
    // Navegación con teclado
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            prevSlide();
            resetCarousel();
        } else if (e.key === 'ArrowRight') {
            nextSlide();
            resetCarousel();
        }
    });
    
    // Efecto parallax mejorado para las imágenes
    const welcomeRight = document.querySelector('.welcome-right');
    if (welcomeRight) {
        welcomeRight.addEventListener('mousemove', (e) => {
            if (window.innerWidth > 992) { // Solo en pantallas grandes
                const rect = welcomeRight.getBoundingClientRect();
                const mouseX = (e.clientX - rect.left) / rect.width - 0.5;
                const mouseY = (e.clientY - rect.top) / rect.height - 0.5;
                
                // Aplicar movimiento sutil a la imagen activa y mejorar el rendimiento con transform 3D
                const activeItem = document.querySelector('.carousel-item.active');
                if (activeItem && activeItem.querySelector('img')) {
                    const img = activeItem.querySelector('img');
                    const transform = `translate3d(${mouseX * -25}px, ${mouseY * -25}px, 0) scale(1.2)`;
                    img.style.transform = transform;
                    img.style.transition = 'transform 0.8s cubic-bezier(0.2, 0.8, 0.2, 1)';
                }
            }
        });
        
        welcomeRight.addEventListener('mouseleave', () => {
            // Resetear posición al salir, pero mantener el scale para la imagen activa
            const activeItem = document.querySelector('.carousel-item.active');
            if (activeItem && activeItem.querySelector('img')) {
                const img = activeItem.querySelector('img');
                img.style.transform = 'scale(1.2)';
                img.style.transition = 'transform 0.8s ease-out';
            }
        });
    }
    
    // Soporte para pantallas táctiles
    let touchStartX = 0;
    let touchEndX = 0;
    
    // Configurar eventos de pantalla táctil para el carrusel
    if (carousel) {
        carousel.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
        }, {passive: true});
        
        carousel.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        }, {passive: true});
    }
    
    // Gestionar el deslizamiento táctil
    const handleSwipe = () => {
        const threshold = 50; // Umbral mínimo de deslizamiento
        
        if (touchEndX < touchStartX - threshold) {
            // Deslizamiento hacia la izquierda - ir a la siguiente diapositiva
            nextSlide();
            resetCarousel();
        } else if (touchEndX > touchStartX + threshold) {
            // Deslizamiento hacia la derecha - ir a la diapositiva anterior
            prevSlide();
            resetCarousel();
        }
    };
    
    // Ajuste para pantallas pequeñas
    const updateMobileLayout = () => {
        if (window.innerWidth <= 768) {
            // Ajustes específicos para móviles
            pauseOnHover = false;
        } else {
            pauseOnHover = true;
        }
    };
    
    // Escuchar cambios de tamaño de ventana
    window.addEventListener('resize', updateMobileLayout);
    
    // Inicializar
    updateMobileLayout();
    showSlide(0); // Mostrar la primera diapositiva
    startCarousel(); // Iniciar el carrusel automático
}

// ======= CARRUSEL DE GALERÍA MEJORADO =======
function initGalleryCarousel() {
    const gallerySlides = document.querySelectorAll('.gallery-slide');
    const galleryThumbs = document.querySelectorAll('.gallery-thumb');
    const galleryCarousel = document.querySelector('.gallery-carousel');
    
    if (!galleryCarousel || gallerySlides.length === 0) return;
    
    const totalSlides = gallerySlides.length;
    let currentGallerySlide = 0;
    let galleryInterval;
    
    // Iniciar el carrusel de galería
    function startGalleryCarousel() {
        galleryInterval = setInterval(() => {
            currentGallerySlide = (currentGallerySlide + 1) % totalSlides;
            updateGallerySlide();
        }, 5000);
    }
    
    // Actualizar slide activo
    function updateGallerySlide() {
        gallerySlides.forEach((slide, index) => {
            if (index === currentGallerySlide) {
                slide.classList.add('active');
            } else {
                slide.classList.remove('active');
            }
        });
        
        // Actualizar miniaturas
        if (galleryThumbs.length > 0) {
            galleryThumbs.forEach((thumb, index) => {
                if (index === currentGallerySlide) {
                    thumb.classList.add('active');
                } else {
                    thumb.classList.remove('active');
                }
            });
        }
        
        // Actualizar contador si existe
        const counter = document.querySelector('.gallery-counter');
        if (counter) {
            counter.textContent = `${currentGallerySlide + 1} / ${totalSlides}`;
        }
        
        // Actualizar puntos indicadores si existen
        const dots = document.querySelectorAll('.gallery-dot');
        if (dots.length > 0) {
            dots.forEach((dot, index) => {
                if (index === currentGallerySlide) {
                    dot.classList.add('active');
                } else {
                    dot.classList.remove('active');
                }
            });
        }
    }
    
    // Agregar funcionalidad a las miniaturas
    if (galleryThumbs.length > 0) {
        galleryThumbs.forEach((thumb, index) => {
            thumb.addEventListener('click', () => {
                currentGallerySlide = index;
                updateGallerySlide();
                // Reiniciar el intervalo
                clearInterval(galleryInterval);
                startGalleryCarousel();
            });
        });
    }
    
    // Crear puntos indicadores para móvil si no existen
    if (galleryCarousel && window.innerWidth <= 768) {
        if (!document.querySelector('.gallery-dots')) {
            const dotsContainer = document.createElement('div');
            dotsContainer.className = 'gallery-dots';
            
            for (let i = 0; i < totalSlides; i++) {
                const dot = document.createElement('span');
                dot.className = 'gallery-dot';
                if (i === 0) dot.classList.add('active');
                
                dot.addEventListener('click', () => {
                    currentGallerySlide = i;
                    updateGallerySlide();
                    clearInterval(galleryInterval);
                    startGalleryCarousel();
                });
                
                dotsContainer.appendChild(dot);
            }
            
            galleryCarousel.appendChild(dotsContainer);
        }
    }
    
    // Crear contador si no existe
    if (galleryCarousel && !document.querySelector('.gallery-counter')) {
        const counter = document.createElement('div');
        counter.className = 'gallery-counter';
        counter.textContent = `1 / ${totalSlides}`;
        galleryCarousel.appendChild(counter);
    }
    
    // Inicializar
    updateGallerySlide();
    startGalleryCarousel();
    
    // Pausar animación al hacer hover
    if (galleryCarousel) {
        galleryCarousel.addEventListener('mouseenter', () => {
            clearInterval(galleryInterval);
        });
        
        galleryCarousel.addEventListener('mouseleave', () => {
            startGalleryCarousel();
        });
        
        // Efecto 3D sutil en hover
        galleryCarousel.addEventListener('mousemove', (e) => {
            const rect = galleryCarousel.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            // Convertir coordenadas a porcentajes desde el centro
            const xPercent = ((x / rect.width) - 0.5) * 2;
            const yPercent = ((y / rect.height) - 0.5) * 2;
            
            // Aplicar efecto 3D ligero basado en posición del mouse
            galleryCarousel.style.transform = `translateY(-12px) rotateX(${-yPercent * 3}deg) rotateY(${xPercent * 3}deg)`;
        });
        
        galleryCarousel.addEventListener('mouseleave', () => {
            galleryCarousel.style.transform = 'translateY(-12px) rotateX(2deg) rotateY(1deg)';
            setTimeout(() => {
                galleryCarousel.style.transition = 'all 0.5s cubic-bezier(0.2, 0.8, 0.2, 1)';
            }, 100);
        });
    }
}

// ======= EFECTOS DE PÁGINA MEJORADOS (ANIMACIONES DE APARICIÓN) =======
function initPageEffects() {
    // Aparecer progresivamente las secciones al hacer scroll
    const sections = document.querySelectorAll('section');
    
    if (sections.length === 0) return;
    
    // Verificar soporte de IntersectionObserver
    if ('IntersectionObserver' in window) {
        // Opciones para el observador de intersección
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.15
        };
        
        // Crear un observador de intersección
        const sectionObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('section-visible');
                    
                    // Desactivar observación después de mostrar la sección
                    sectionObserver.unobserve(entry.target);
                    
                    // Animar elementos dentro de la sección
                    animateSectionElements(entry.target);
                }
            });
        }, observerOptions);
        
        // Observar cada sección
        sections.forEach(section => {
            section.classList.add('section-hidden');
            sectionObserver.observe(section);
        });
    } else {
        // Fallback para navegadores sin soporte para IntersectionObserver
        sections.forEach(section => {
            section.classList.add('section-visible');
            animateSectionElements(section);
        });
    }
    
    // Función para animar elementos dentro de cada sección
    function animateSectionElements(section) {
        // Añadir retraso a los elementos para animación secuencial
        const animElements = section.querySelectorAll('.offering-card, .room-card, .testimonial-card, .about-stats .stat-item');
        animElements.forEach((el, index) => {
            el.style.transitionDelay = `${index * 0.1}s`;
            setTimeout(() => {
                el.classList.add('element-visible');
            }, 100);
        });
    }
    
    // Añadir clase CSS para las animaciones
    const style = document.createElement('style');
    style.textContent = `
        .section-hidden {
            opacity: 0;
            transform: translateY(30px);
            transition: opacity 0.8s ease-out, transform 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
        }
        
        .section-visible {
            opacity: 1;
            transform: translateY(0);
        }
        
        .offering-card, .room-card, .testimonial-card, .about-stats .stat-item {
            opacity: 0;
            transform: translateY(30px);
            transition: opacity 0.6s ease-out, transform 0.6s cubic-bezier(0.2, 0.8, 0.2, 1);
        }
        
        .element-visible {
            opacity: 1;
            transform: translateY(0);
        }
        
        .offering-icon, .about-experience, .review-badge {
            transition-delay: 0.2s;
        }
    `;
    document.head.appendChild(style);
    
    // Función auxiliar para verificar si un elemento está en el viewport
    function isElementInViewport(el) {
        const rect = el.getBoundingClientRect();
        return (
            rect.top <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.bottom >= 0
        );
    }
}

// ======= FUNCIONES ADICIONALES PARA MEJORAR LA GALERÍA Y LA SECCIÓN DE BIENVENIDA =======

// Mejorar la galería para móvil
function enhanceGalleryForMobile() {
    const galleryCarousel = document.querySelector('.gallery-carousel');
    const gallerySlides = document.querySelectorAll('.gallery-slide');
    
    if (!galleryCarousel || gallerySlides.length === 0) return;
    
    // Crear y añadir puntos indicadores para móvil
    if (window.innerWidth <= 768) {
        if (!document.querySelector('.gallery-dots')) {
            const dotsContainer = document.createElement('div');
            dotsContainer.className = 'gallery-dots';
            
            gallerySlides.forEach((slide, index) => {
                const dot = document.createElement('span');
                dot.className = 'gallery-dot';
                if (index === 0) dot.classList.add('active');
                
                // Agregar funcionalidad a los puntos
                dot.addEventListener('click', () => {
                    // Actualizar el slide activo
                    gallerySlides.forEach(s => s.classList.remove('active'));
                    gallerySlides[index].classList.add('active');
                    
                    // Actualizar el punto activo
                    const allDots = document.querySelectorAll('.gallery-dot');
                    allDots.forEach(d => d.classList.remove('active'));
                    dot.classList.add('active');
                    
                    // Actualizar miniaturas
                    const thumbs = document.querySelectorAll('.gallery-thumb');
                    if (thumbs.length > 0) {
                        thumbs.forEach((thumb, i) => {
                            if (i === index) {
                                thumb.classList.add('active');
                            } else {
                                thumb.classList.remove('active');
                            }
                        });
                    }
                });
                
                dotsContainer.appendChild(dot);
            });
            
            galleryCarousel.appendChild(dotsContainer);
        }
    }
    
    // Asegurarnos de que el botón "Ver todas" sea accesible en dispositivos táctiles
    const galleryBtn = document.querySelector('.gallery-btn');
    if (galleryBtn) {
        galleryBtn.style.opacity = '1';
        galleryBtn.style.transform = 'translateY(0)';
    }
    
    // Crear contador si no existe
    if (!document.querySelector('.gallery-counter')) {
        const counter = document.createElement('div');
        counter.className = 'gallery-counter';
        counter.textContent = `1 / ${gallerySlides.length}`;
        galleryCarousel.appendChild(counter);
    }
    
    // Mejorar accesibilidad táctil
    galleryCarousel.addEventListener('touchstart', function() {
        // Asegurar que los elementos sean visibles en toque
        if (galleryBtn) {
            galleryBtn.style.opacity = '1';
            galleryBtn.style.transform = 'translateY(0)';
        }
    }, { passive: true });
}

// Mejorar responsividad de la sección de bienvenida
function enhanceWelcomeResponsiveness() {
    const welcomeContainer = document.querySelector('.welcome-container');
    const welcomeLeft = document.querySelector('.welcome-left');
    const welcomeRight = document.querySelector('.welcome-right');
    
    if (!welcomeContainer || !welcomeLeft || !welcomeRight) return;
    
    // Ajustar altura basada en la orientación
    function adjustHeight() {
        const isLandscape = window.innerWidth > window.innerHeight;
        const isMobile = window.innerWidth <= 768;
        
        if (isMobile && !isLandscape) {
            // Modo retrato en móvil
            welcomeLeft.style.minHeight = 'auto';
            welcomeRight.style.minHeight = '60vh';
            welcomeContainer.style.minHeight = 'auto';
        } else if (isMobile && isLandscape) {
            // Modo landscape en móvil
            welcomeLeft.style.minHeight = '100%';
            welcomeRight.style.minHeight = '100%';
            welcomeContainer.style.height = '100vh';
            welcomeContainer.style.minHeight = 'auto';
        } else {
            // Desktop
            welcomeContainer.style.minHeight = '100vh';
            welcomeLeft.style.minHeight = '';
            welcomeRight.style.minHeight = '';
        }
    }
    
    // Llamar al ajuste inicial
    adjustHeight();
    
    // Actualizar en cambio de tamaño o orientación
    window.addEventListener('resize', adjustHeight);
    window.addEventListener('orientationchange', adjustHeight);
}