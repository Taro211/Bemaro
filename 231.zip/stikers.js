// Script para añadir stickers de juguetes mexicanos tradicionales
// que solo aparecen cuando el tema festivo está activado
// Versión mejorada con responsividad y prevención de overflow horizontal

document.addEventListener('DOMContentLoaded', function() {
    // Definición de rutas a imágenes SVG de juguetes
    const toysSVGPaths = {
        'trompo': 'imagenes/festive/trompo.svg',
        'balero': 'imagenes/festive/balero.svg',
        'oso': 'imagenes/festive/oso.svg',
        'yoyo': 'imagenes/festive/yoyo.svg'
    };

    // Nombres de los juguetes para selección
    const toyNames = Object.keys(toysSVGPaths);
    
    // Seguimiento de los últimos juguetes utilizados para evitar repeticiones
    let usedToys = [];
    
    // Función para seleccionar un juguete sin repetir el último usado
    function getNextRandomToy() {
        // Si ya hemos usado todos los juguetes, reiniciamos
        if (usedToys.length >= toyNames.length) {
            usedToys = [usedToys[usedToys.length - 1]]; // Mantener solo el último usado
        }
        
        // Filtrar juguetes disponibles (los que no se han usado recientemente)
        const availableToys = toyNames.filter(toy => !usedToys.includes(toy));
        
        // Seleccionar uno aleatorio de los disponibles
        const selectedToy = availableToys[Math.floor(Math.random() * availableToys.length)];
        
        // Añadir a la lista de usados
        usedToys.push(selectedToy);
        
        return selectedToy;
    }

    // Secciones donde colocaremos los stickers
    const sections = [
        '.welcome-container', 
        '.offerings-section',
        '.rooms-section',
        '.gallery-section',
        '.about-section',
        '.testimonials-section',
        '.cta-section'
    ];

    // POSICIONES MEJORADAS: Solo en esquinas y bordes extremos, con margen de seguridad
    // para prevenir desbordamiento horizontal
    const safePositions = [
        // Esquina superior izquierda
        { top: '5%', left: '2%' },
        // Esquina superior derecha - reducido para evitar overflow
        { top: '8%', left: '94%' },
        // Esquina inferior izquierda
        { top: '85%', left: '2%' },
        // Esquina inferior derecha - reducido para evitar overflow
        { top: '82%', left: '92%' },
        // Borde izquierdo centro
        { top: '40%', left: '1%' },
        // Borde derecho centro - reducido para evitar overflow
        { top: '45%', left: '95%' },
        // Posiciones adicionales más seguras - solo en bordes
        { top: '70%', left: '1.5%' },
        { top: '25%', left: '93%' },
        { top: '60%', left: '1%' },
        { top: '12%', left: '90%' }
    ];

    // Posiciones alternativas para dispositivos móviles (optimizadas para visibilidad y bordes)
    const mobileSafePositions = [
        // Esquinas más visibles para móvil - reducidas para evitar overflow
        { top: '3%', left: '2%' },
        { top: '3%', left: '80%' },
        { top: '95%', left: '2%' },
        { top: '88%', left: '80%' },
        // Posiciones laterales mejoradas
        { top: '25%', left: '1%' },
        { top: '25%', left: '85%' },
        { top: '50%', left: '1%' },
        { top: '50%', left: '86%' },
        { top: '75%', left: '2%' },
        { top: '75%', left: '82%' }
        // Eliminamos posiciones de la mitad que pueden tapar contenido
    ];

    // Objeto para rastrear qué posiciones se han utilizado en cada sección
    let usedPositionsMap = {};
    
    // Variable para almacenar todos los stickers creados
    let allStickers = [];
    
    // Función para determinar si estamos en un dispositivo móvil
    function isMobileDevice() {
        return window.innerWidth <= 768;
    }
    
    // Función para determinar el tamaño de sticker basado en viewport
    // Reducido para evitar problemas de overflow
    function getResponsiveStickerSize() {
        const vw = window.innerWidth;
        
        // Tamaño basado en viewport (reducido para mejor contención)
        if (vw <= 576) {
            // Para móviles muy pequeños - tamaños reducidos
            return Math.floor(Math.random() * 10) + 35; // 35-45px
        } else if (vw <= 768) {
            // Para móviles - tamaños reducidos
            return Math.floor(Math.random() * 10) + 40; // 40-50px
        } else if (vw <= 992) {
            // Para tablets - tamaños reducidos
            return Math.floor(Math.random() * 15) + 45; // 45-60px
        } else {
            // Para escritorio - tamaños reducidos
            return Math.floor(Math.random() * 20) + 50; // 50-70px
        }
    }
    
    // Función para determinar cuántos stickers por sección
    // Reducidos para minimizar posibilidad de overflow y solapamiento
    function getStickerCountForSection() {
        const vw = window.innerWidth;
        
        if (vw <= 768) {
            // En móviles, máximo 1 sticker por sección
            return 1;
        } else {
            // En escritorio, 1-2 stickers por sección
            return Math.floor(Math.random() * 2) + 1; // 1-2 stickers
        }
    }

    // Función para crear stickers
    function createStickers() {
        // Limpiar stickers existentes
        clearAllStickers();
        
        // Objeto para rastrear qué posiciones se han utilizado en cada sección
        usedPositionsMap = {};
        
        // Seleccionar conjunto de posiciones según dispositivo
        const positionsToUse = isMobileDevice() ? mobileSafePositions : safePositions;
        
        // Crear stickers en cada sección
        sections.forEach(sectionSelector => {
            const section = document.querySelector(sectionSelector);
            if (!section) return;
            
            // Configurar posicionamiento relativo si no lo tiene
            const currentPosition = window.getComputedStyle(section).position;
            if (currentPosition === 'static') {
                section.style.position = 'relative';
            }
            
            // NUEVO: Verificar overflow del contenedor
            section.style.overflow = 'hidden';
            
            // Inicializar registro de posiciones usadas para esta sección
            usedPositionsMap[sectionSelector] = [];
            
            // Determinar el número de stickers para esta sección
            const stickersCount = getStickerCountForSection();
            
            for (let i = 0; i < stickersCount; i++) {
                // Elegir un juguete aleatorio sin repetir consecutivos
                const toyName = getNextRandomToy();
                const toyPath = toysSVGPaths[toyName];
                
                // Crear el sticker como un elemento img
                const sticker = document.createElement('img');
                sticker.className = 'festive-toy-sticker';
                sticker.src = toyPath;
                sticker.alt = toyName;
                
                // Tamaño responsivo basado en viewport (reducido)
                const size = getResponsiveStickerSize();
                
                // Seleccionar una posición que no haya sido usada en esta sección
                let position;
                let attempts = 0;
                const maxAttempts = 10; // Limitar intentos para evitar bucles infinitos
                
                do {
                    position = positionsToUse[Math.floor(Math.random() * positionsToUse.length)];
                    attempts++;
                    
                    // Si hemos intentado muchas veces, ajustar ligeramente una posición existente
                    if (attempts >= maxAttempts) {
                        const basePosition = positionsToUse[Math.floor(Math.random() * positionsToUse.length)];
                        // Ajustar la posición ligeramente para evitar superposición
                        position = {
                            top: parseFloat(basePosition.top) + (Math.random() * 5 - 2.5) + '%',
                            left: parseFloat(basePosition.left) + (Math.random() * 5 - 2.5) + '%'
                        };
                        break;
                    }
                    
                    // Verificar si esta posición ya está siendo utilizada
                } while (isPositionUsed(sectionSelector, position));
                
                // NUEVO: Verificar que la posición esté completamente dentro de los bordes
                // Ajustar posiciones en el borde derecho para prevenir overflow
                if (parseFloat(position.left) > 90) {
                    // Si está en el borde derecho, asegurarnos que está alineado a la derecha
                    // pero dentro del contenedor
                    position.left = (isMobileDevice() ? '82%' : '94%');
                }
                
                // Registrar la posición como usada
                usedPositionsMap[sectionSelector].push({
                    position: position,
                    size: size
                });
                
                // Rotación aleatoria para efecto de sticker
                const rotation = Math.floor(Math.random() * 40) - 20; // -20° a +20°
                
                // Aplicar estilos con unidades CSS mejoradas para responsividad
                // MEJORADO: Agregado 'object-fit: contain' para evitar desbordamiento
                sticker.style.cssText = `
                    position: absolute;
                    top: ${position.top};
                    left: ${position.left};
                    width: ${size}px;
                    height: auto;
                    transform: rotate(${rotation}deg);
                    opacity: 0;
                    transition: opacity 0.5s ease, transform 0.3s ease;
                    z-index: 50;
                    pointer-events: none;
                    display: none;
                    filter: drop-shadow(2px 3px 4px rgba(0,0,0,0.4));
                    max-width: ${window.innerWidth <= 768 ? '12vw' : '10vw'}; /* Reducido para mejor contención */
                    min-width: ${window.innerWidth <= 576 ? '30px' : '35px'}; /* Tamaño mínimo reducido */
                    object-fit: contain; /* Asegurar contención dentro del tamaño */
                    transform-origin: center center; /* Mejor rotación */
                `;
                
                // NUEVO: Ajustar colocación para imágenes en el borde derecho
                if (parseFloat(position.left) > 80) {
                    sticker.style.transformOrigin = 'right center';
                } else if (parseFloat(position.left) < 20) {
                    sticker.style.transformOrigin = 'left center';
                }
                
                // Añadir a la sección
                section.appendChild(sticker);
                
                // Agregar a la lista de todos los stickers
                allStickers.push(sticker);
            }
        });
        
        // Actualizar visibilidad después de crear
        updateStickersVisibility();
    }
    
    // Función para limpiar todos los stickers existentes
    function clearAllStickers() {
        const existingStickers = document.querySelectorAll('.festive-toy-sticker');
        existingStickers.forEach(sticker => {
            sticker.remove();
        });
        allStickers = [];
    }

    // Función para verificar si una posición está demasiado cerca de otra ya utilizada
    function isPositionUsed(sectionSelector, newPosition) {
        const usedPositions = usedPositionsMap[sectionSelector] || [];
        
        // Convertir porcentajes a valores numéricos
        const newTop = parseFloat(newPosition.top);
        const newLeft = parseFloat(newPosition.left);
        
        // Verificar si hay superposición con posiciones existentes
        return usedPositions.some(item => {
            const existingTop = parseFloat(item.position.top);
            const existingLeft = parseFloat(item.position.left);
            
            // Calcular distancia mínima basada en el tamaño y viewport
            // Aumentar distancia mínima en pantallas pequeñas
            const minDistanceFactor = window.innerWidth <= 768 ? 10 : 7; // Aumentado para mayor separación
            const minDistance = (item.size / 2) / minDistanceFactor;
            
            // Calcular distancia entre las posiciones (en unidades de porcentaje)
            const distance = Math.sqrt(
                Math.pow(newTop - existingTop, 2) + 
                Math.pow(newLeft - existingLeft, 2)
            );
            
            // Si la distancia es menor que la mínima, hay superposición
            return distance < minDistance;
        });
    }

    // Función para mostrar/ocultar los stickers según el tema
    function updateStickersVisibility() {
        const isDarkMode = document.body.classList.contains('dark-mode');
        const stickers = allStickers.length > 0 ? allStickers : document.querySelectorAll('.festive-toy-sticker');
        
        stickers.forEach(sticker => {
            if (isDarkMode) {
                sticker.style.display = 'block';
                // Retrasar la transición de opacidad para un efecto suave
                setTimeout(() => {
                    sticker.style.opacity = '0.85'; // Reducido para mejor legibilidad
                    
                    // Extraer el valor de rotación actual
                    const currentRotation = sticker.style.transform.match(/-?\d+/) ? 
                                          sticker.style.transform.match(/-?\d+/)[0] : 
                                          '0';
                                          
                    sticker.style.transform = `rotate(${currentRotation}deg) scale(1)`;
                }, 100);
            } else {
                sticker.style.opacity = '0';
                
                // Extraer el valor de rotación actual
                const currentRotation = sticker.style.transform.match(/-?\d+/) ? 
                                      sticker.style.transform.match(/-?\d+/)[0] : 
                                      '0';
                                      
                sticker.style.transform = `rotate(${currentRotation}deg) scale(0.95)`;
                // Ocultar completamente después de la transición
                setTimeout(() => {
                    sticker.style.display = 'none';
                }, 500);
            }
        });
    }
    
    // Función debounce para limitar llamadas frecuentes a funciones
    function debounce(func, delay) {
        let timer;
        return function() {
            const context = this;
            const args = arguments;
            clearTimeout(timer);
            timer = setTimeout(() => {
                func.apply(context, args);
            }, delay);
        };
    }
    
    // NUEVO: Función para corregir cualquier desbordamiento detectado
    function fixOverflows() {
        // Comprobar si hay scrollbar horizontal
        if (document.body.scrollWidth > document.body.clientWidth) {
            console.log("Detectado overflow horizontal - corrigiendo stickers");
            
            // Ajustar cualquier sticker que pueda estar causando overflow
            const stickers = document.querySelectorAll('.festive-toy-sticker');
            
            stickers.forEach(sticker => {
                const rect = sticker.getBoundingClientRect();
                
                // Si el sticker se extiende más allá del ancho de la ventana
                if (rect.right > window.innerWidth || rect.left < 0) {
                    // Ajustar tamaño
                    const currentSize = parseInt(sticker.style.width);
                    sticker.style.width = (currentSize * 0.8) + 'px'; // Reducir 20%
                    
                    // Si está en el borde derecho, ajustar posición
                    if (rect.right > window.innerWidth) {
                        const left = parseFloat(sticker.style.left);
                        if (left > 50) { // Si está a la derecha
                            sticker.style.left = (isMobileDevice() ? '80%' : '90%');
                        }
                    }
                    
                    // Si está en el borde izquierdo, ajustar posición
                    if (rect.left < 0) {
                        sticker.style.left = '2%';
                    }
                }
            });
        }
    }
    
    // Recrear stickers cuando la ventana cambia de tamaño significativamente
    const recreateStickersDebounced = debounce(function() {
        // Solo recrear si estamos en tema festivo
        if (document.body.classList.contains('dark-mode')) {
            createStickers();
            // Verificar y corregir overflows después de recrear
            setTimeout(fixOverflows, 300);
        }
    }, 250);

    // Observar cambios en el tema
    const observer = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            if (mutation.attributeName === 'class') {
                // Si estamos cambiando a dark-mode (festivo), crear stickers nuevos
                if (document.body.classList.contains('dark-mode')) {
                    createStickers();
                    // Verificar y corregir overflows después de crear
                    setTimeout(fixOverflows, 300);
                } else {
                    // Solo actualizar visibilidad si estamos cambiando a modo claro
                    updateStickersVisibility();
                }
            }
        });
    });
    
    observer.observe(document.body, { attributes: true });
    
    // Manejar eventos de redimensionamiento
    window.addEventListener('resize', recreateStickersDebounced);
    
    // Manejar cambios de orientación específicamente
    window.addEventListener('orientationchange', function() {
        // Esperar a que termine la transición de orientación
        setTimeout(() => {
            createStickers();
            // Verificar y corregir overflows después de recrear
            setTimeout(fixOverflows, 300);
        }, 300);
    });
    
    // NUEVO: Verificar periódicamente si hay overflow horizontal y corregir si es necesario
    setInterval(fixOverflows, 2000);
    
    // Verificar si hay error al cargar las imágenes y manejar elegantemente
    document.addEventListener('error', function(e) {
        const target = e.target;
        if (target.tagName === 'IMG' && target.classList.contains('festive-toy-sticker')) {
            console.warn(`No se pudo cargar la imagen del sticker: ${target.src}`);
            target.style.display = 'none';
            
            // Eliminar del array de stickers si existe
            const index = allStickers.indexOf(target);
            if (index > -1) {
                allStickers.splice(index, 1);
            }
        }
    }, true);
    
    // Comprobar el rendimiento del dispositivo para ajustar animaciones
    function checkPerformance() {
        // Verificar si estamos en un dispositivo móvil de baja capacidad
        const isLowPowerDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) && 
                                 (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);
        
        // Si es un dispositivo de menor capacidad, ajustar transiciones
        if (isLowPowerDevice) {
            const style = document.createElement('style');
            style.textContent = `
                .festive-toy-sticker {
                    transition: opacity 0.3s linear, transform 0.2s linear !important;
                    filter: drop-shadow(1px 2px 2px rgba(0,0,0,0.25)) !important;
                }
            `;
            document.head.appendChild(style);
        }
        
        // NUEVO: Agregar estilos para prevenir desbordamiento
        const preventOverflowStyle = document.createElement('style');
        preventOverflowStyle.textContent = `
            /* Prevenir overflow horizontal en todo el sitio */
            body {
                overflow-x: hidden;
            }
            
            /* Añadir contención a secciones con stickers */
            ${sections.join(', ')} {
                position: relative;
                overflow: hidden;
            }
        `;
        document.head.appendChild(preventOverflowStyle);
    }
    
    // Verificar rendimiento al inicio
    checkPerformance();
    
    // Crear stickers iniciales si estamos en modo oscuro desde el principio
    if (document.body.classList.contains('dark-mode')) {
        createStickers();
        // Verificar y corregir overflows después de crear
        setTimeout(fixOverflows, 300);
    }
});