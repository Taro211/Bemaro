/**
 * BEMARO - Blog de Eventos en CDMX
 * Sistema de carga dinámica de publicaciones desde carpetas locales
 */

$(document).ready(function() {
    // Añadir estilos CSS para la adaptación de texto y fechas de eventos
    $('head').append(`
        <style>
            /* Estilos para truncar texto */
            .text-truncate {
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                max-width: 100%;
            }
            
            .text-multiline-truncate {
                display: -webkit-box;
                -webkit-line-clamp: 4;
                -webkit-box-orient: vertical;
                overflow: hidden;
                text-overflow: ellipsis;
                max-height: 6em;
                line-height: 1.5;
            }
            
            .blog-post-title {
                font-size: 1.2rem;
                line-height: 1.3;
                margin-bottom: 0.5rem;
                max-height: 2.6em;
                cursor: pointer;
            }
            
            .blog-post-title:hover {
                color: var(--color-turquoise);
            }
            
            body.dark-mode .blog-post-title:hover {
                color: var(--color-purple);
            }
            
            .blog-post-excerpt {
                font-size: 0.9rem;
                line-height: 1.5;
                min-height: 4.5em;
            }
            
            .modal-title {
                font-size: 1.8rem;
                line-height: 1.2;
                word-wrap: break-word;
            }
            
            .modal-content-wrapper {
                word-wrap: break-word;
                overflow-wrap: break-word;
            }
            
            .modal-content-wrapper p {
                margin-bottom: 1rem;
            }
            
            .modal-content-wrapper ul, .modal-content-wrapper ol {
                padding-left: 2rem;
                margin-bottom: 1rem;
            }
            
            .modal-content-wrapper img {
                max-width: 100%;
                height: auto;
                margin: 1rem 0;
            }
            
            /* Estilos para fechas de publicación y eventos */
            .dates-container {
                margin-bottom: 15px;
            }
            
            .upload-date {
                display: flex;
                align-items: center;
                color: #777;
                font-size: 0.85rem;
                margin-bottom: 8px;
            }
            
            body.dark-mode .upload-date {
                color: #999;
            }
            
            .upload-date i {
                margin-right: 8px;
                color: var(--color-turquoise);
            }
            
            body.dark-mode .upload-date i {
                color: var(--color-purple);
            }
            
            .event-dates {
                display: flex;
                align-items: center;
                position: relative;
            }
            
            .event-date {
                display: flex;
                align-items: center;
                color: #333;
                font-size: 0.85rem;
                padding: 4px 10px;
                background-color: rgba(23, 165, 137, 0.1);
                border-radius: 4px;
                margin-right: 5px;
                transition: background-color 0.3s ease;
                font-weight: 500;
            }
            
            body.dark-mode .event-date {
                color: #eee;
                background-color: rgba(175, 83, 154, 0.1);
            }
            
            .event-date i {
                margin-right: 6px;
                color: var(--color-yellow);
            }
            
            .date-toggle {
                cursor: pointer;
                padding: 4px;
                border-radius: 4px;
                color: var(--color-turquoise);
                transition: background-color 0.3s ease;
            }
            
            body.dark-mode .date-toggle {
                color: var(--color-purple);
            }
            
            .date-toggle:hover {
                background-color: rgba(23, 165, 137, 0.1);
            }
            
            body.dark-mode .date-toggle:hover {
                background-color: rgba(175, 83, 154, 0.1);
            }
            
            .dates-dropdown {
                position: absolute;
                top: 100%;
                right: 0;
                background-color: white;
                border-radius: 6px;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
                padding: 8px 0;
                z-index: 10;
                min-width: 180px;
                max-width: 250px;
                display: none;
                flex-direction: column;
            }
            
            body.dark-mode .dates-dropdown {
                background-color: #2a2a2a;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            }
            
            .dates-dropdown.show {
                display: flex;
            }
            
            .dropdown-date {
                padding: 6px 12px;
                font-size: 0.85rem;
                color: #333;
                cursor: pointer;
                transition: background-color 0.2s ease;
                display: flex;
                align-items: center;
            }
            
            body.dark-mode .dropdown-date {
                color: #eee;
            }
            
            .dropdown-date:hover {
                background-color: rgba(23, 165, 137, 0.1);
            }
            
            body.dark-mode .dropdown-date:hover {
                background-color: rgba(175, 83, 154, 0.1);
            }
            
            .dropdown-date i {
                margin-right: 8px;
                color: var(--color-yellow);
                width: 16px;
                text-align: center;
            }
            
            /* Ajuste para la vista de tarjeta */
            .blog-post-header {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                margin-bottom: 10px;
            }
            
            .blog-post-dates {
                display: flex;
                flex-direction: column;
                align-items: flex-end;
                margin-left: 10px;
                min-width: 120px;
            }
            
            .blog-post-upload-date {
                display: flex;
                align-items: center;
                color: #777;
                font-size: 0.8rem;
                margin-bottom: 5px;
            }
            
            body.dark-mode .blog-post-upload-date {
                color: #999;
            }
            
            .blog-post-upload-date i {
                margin-right: 5px;
                color: var(--color-turquoise);
            }
            
            body.dark-mode .blog-post-upload-date i {
                color: var(--color-purple);
            }
            
            .blog-post-event-date {
                display: flex;
                align-items: center;
                color: #333;
                font-size: 0.8rem;
                font-weight: 500;
                background-color: rgba(23, 165, 137, 0.1);
                padding: 3px 8px;
                border-radius: 4px;
            }
            
            body.dark-mode .blog-post-event-date {
                color: #eee;
                background-color: rgba(175, 83, 154, 0.1);
            }
            
            .blog-post-event-date i {
                margin-right: 5px;
                color: var(--color-yellow);
            }
            
            .multi-date-indicator {
                margin-left: 5px;
                color: var(--color-turquoise);
                cursor: pointer;
            }
            
            body.dark-mode .multi-date-indicator {
                color: var(--color-purple);
            }
            
            /* Estilos para el modal de fecha */
            .modal-dates {
                display: flex;
                flex-direction: column;
                margin-bottom: 15px;
            }
            
            .modal-upload-date {
                display: flex;
                align-items: center;
                color: #777;
                font-size: 0.9rem;
                margin-bottom: 8px;
            }
            
            body.dark-mode .modal-upload-date {
                color: #999;
            }
            
            .modal-upload-date i {
                margin-right: 8px;
                color: var(--color-turquoise);
            }
            
            body.dark-mode .modal-upload-date i {
                color: var(--color-purple);
            }
            
            .modal-event-dates {
                display: flex;
                align-items: center;
                flex-wrap: wrap;
                gap: 8px;
            }
            
            .modal-event-date {
                display: flex;
                align-items: center;
                color: #333;
                font-size: 0.9rem;
                padding: 5px 12px;
                background-color: rgba(23, 165, 137, 0.1);
                border-radius: 4px;
                transition: background-color 0.3s ease;
                font-weight: 500;
            }
            
            body.dark-mode .modal-event-date {
                color: #eee;
                background-color: rgba(175, 83, 154, 0.1);
            }
            
            .modal-event-date i {
                margin-right: 8px;
                color: var(--color-yellow);
            }
            
            @media (max-width: 768px) {
                .blog-post-title {
                    font-size: 1.1rem;
                }
                
                .modal-title {
                    font-size: 1.5rem;
                }
                
                .text-multiline-truncate {
                    -webkit-line-clamp: 3;
                    max-height: 4.5em;
                }
                
                .event-date, .modal-event-date {
                    font-size: 0.8rem;
                    padding: 3px 8px;
                }
            }
        </style>
    `);

    // Configuración
    const blogConfig = {
        rootFolder: 'blog', // Carpeta principal de publicaciones
        maxPostsPerPage: 6, // Número de publicaciones por página
        initialLoadCount: 6, // Número inicial de publicaciones a cargar
        loadMoreCount: 3, // Número de publicaciones a cargar con "cargar más"
        maxRecentPosts: 5, // Número de publicaciones recientes a mostrar en el sidebar
        uploadDateFormat: { 
            day: '2-digit', 
            month: '2-digit', 
            year: 'numeric' 
        },
        eventDateFormat: {
            day: '2-digit', 
            month: '2-digit', 
            year: 'numeric'
        },
        // Categorías disponibles para filtrar
        categories: {
            cultural: {
                name: "Cultural",
                icon: "fas fa-landmark"
            },
            gastronomico: {
                name: "Gastronómico",
                icon: "fas fa-utensils"
            },
            musica: {
                name: "Música",
                icon: "fas fa-music"
            }
        }
    };

    // Variables globales
    let allPosts = [];
    let filteredPosts = [];
    let displayedPosts = 0;
    let isLoading = false;
    let activeFilter = 'all';
    let searchQuery = '';

    // Referencias a elementos DOM
    const blogGrid = $('#blog-grid');
    const sidebarContent = $('.sidebar-content');
    const blogLoader = $('.blog-loader');
    const sidebarLoader = $('.sidebar-loader');
    const loadMoreBtn = $('.load-more-btn');
    const blogModal = $('.blog-modal');
    const filterBtns = $('.filter-btn');
    const searchInput = $('#blog-search');
    const searchBtn = $('.search-btn');

    // Mostrar información sobre el archivo index.json necesario
    createIndexJsonInfo();
    
    // Inicializar blog
    initBlog();

    /**
     * Inicializa el blog y carga las publicaciones
     */
    function initBlog() {
        showLoader();
        
        // Comenzar a escanear carpetas y cargar publicaciones
        scanBlogFolders().then(() => {
            hideLoader();
            
            if (allPosts.length > 0) {
                // Aplicar filtro actual (inicialmente 'all')
                applyFilters();
                
                // Cargar publicaciones iniciales
                loadPosts(blogConfig.initialLoadCount);
                
                // Cargar publicaciones recientes en el sidebar
                loadRecentPosts();
                
                // Inicializar eventos
                initEvents();
            } else {
                showEmptyMessage();
            }
        }).catch(error => {
            console.error('Error al cargar el blog:', error);
            showErrorMessage('No se pudieron cargar las publicaciones del blog. Por favor, intenta de nuevo más tarde.');
        });
    }

    /**
     * Escanea las carpetas del blog para encontrar publicaciones
     * Cada carpeta debe contener: portada.jpg, titulo.txt, intro.txt, cuerpo.txt, categoria.txt, fecha.txt (opcional)
     */
    async function scanBlogFolders() {
        allPosts = [];
        
        try {
            console.log('Iniciando escaneo de carpetas en:', blogConfig.rootFolder);
            
            // En entornos web, no podemos listar directorios directamente por seguridad
            // Vamos a intentar usar window.fs.readFile si está disponible (para entornos específicos)
            let folderNames = [];
            
            try {
                if (typeof window.fs !== 'undefined' && window.fs.readFile) {
                    console.log('Usando window.fs.readFile para escanear directorios');
                    
                    // Intentar leer un archivo de índice que liste los directorios
                    const indexContent = await window.fs.readFile(`${blogConfig.rootFolder}/index.json`, { encoding: 'utf8' });
                    const indexData = JSON.parse(indexContent);
                    folderNames = indexData.directories || [];
                    
                    console.log('Directorios encontrados en index.json:', folderNames);
                } else {
                    // Intentar cargar un archivo index.json manualmente
                    console.log('Intentando cargar index.json mediante fetch');
                    const response = await fetch(`${blogConfig.rootFolder}/index.json`);
                    if (response.ok) {
                        const indexData = await response.json();
                        folderNames = indexData.directories || [];
                        console.log('Directorios encontrados en index.json mediante fetch:', folderNames);
                    } else {
                        throw new Error('No se pudo cargar index.json');
                    }
                }
            } catch (err) {
                console.warn('Error al leer el índice de directorios:', err);
                console.log('Usando lista de directorios de ejemplo para demostración');
                
                // Lista de ejemplo para demostración
                folderNames = [
                    '01-04-25', '28-03-25', '21-03-25', '15-03-25', '08-03-25',
                    '01-03-25', '22-02-25', '15-02-25', '08-02-25', '01-02-25'
                ];
            }
            
            // Filtrar solo carpetas con formato de fecha (dd-mm-aa)
            folderNames = folderNames.filter(entry => {
                return /^\d{2}-\d{2}-\d{2}$/.test(entry);
            });
            
            console.log('Carpetas a procesar:', folderNames);
            
            // Para cada carpeta, cargar los archivos necesarios
            for (const folderName of folderNames) {
                try {
                    const uploadDate = parsePostDate(folderName);
                    
                    if (uploadDate) {
                        // Ruta base para esta publicación
                        const basePath = `${blogConfig.rootFolder}/${folderName}`;
                        console.log(`Procesando carpeta: ${basePath}`);
                        
                        // Cargar contenido de los archivos
                        let title, intro, body, imagePath, category, eventDates, location, mapLink;
                        
                        try {
                            // Intentar leer los archivos usando window.fs si está disponible
                            if (typeof window.fs !== 'undefined' && window.fs.readFile) {
                                title = await readFileWithFS(`${basePath}/titulo.txt`);
                                intro = await readFileWithFS(`${basePath}/intro.txt`);
                                body = await readFileWithFS(`${basePath}/cuerpo.txt`);
                                
                                // Intentar leer el archivo de categoría
                                try {
                                    category = await readFileWithFS(`${basePath}/categoria.txt`);
                                } catch (categoryError) {
                                    console.warn(`Archivo categoria.txt no encontrado en ${folderName}, se determinará automáticamente`);
                                    category = null;
                                }
                                
                                // Intentar leer el archivo de fechas de eventos
                                try {
                                    const eventDatesContent = await readFileWithFS(`${basePath}/fecha.txt`);
                                    eventDates = parseEventDates(eventDatesContent);
                                } catch (datesError) {
                                    console.warn(`Archivo fecha.txt no encontrado en ${folderName}, se utilizará solo la fecha de subida`);
                                    eventDates = null;
                                }
                                
                                // Intentar leer el archivo de ubicación
                                try {
                                    location = await readFileWithFS(`${basePath}/ubicacion.txt`);
                                    console.log(`Ubicación cargada para ${folderName}: ${location}`);
                                    
                                    // Intentar leer el archivo de enlace al mapa
                                    try {
                                        mapLink = await readFileWithFS(`${basePath}/link.txt`);
                                        console.log(`Enlace al mapa cargado para ${folderName}: ${mapLink}`);
                                    } catch (linkError) {
                                        console.warn(`Archivo link.txt no encontrado en ${folderName}, se usará un enlace predeterminado`);
                                        mapLink = "https://maps.app.goo.gl/PqjBFeXsMxhYBziY9"; // Enlace predeterminado
                                    }
                                } catch (locationError) {
                                    console.warn(`Archivo ubicacion.txt no encontrado en ${folderName}, se usará una ubicación predeterminada`);
                                    location = "Ciudad de México, CDMX";
                                    mapLink = "https://maps.app.goo.gl/PqjBFeXsMxhYBziY9"; // Enlace predeterminado
                                }
                            } else {
                                // Intentar con fetch
                                title = await readFileWithFetch(`${basePath}/titulo.txt`);
                                intro = await readFileWithFetch(`${basePath}/intro.txt`);
                                body = await readFileWithFetch(`${basePath}/cuerpo.txt`);
                                
                                // Intentar leer el archivo de categoría
                                try {
                                    category = await readFileWithFetch(`${basePath}/categoria.txt`);
                                } catch (categoryError) {
                                    console.warn(`Archivo categoria.txt no encontrado en ${folderName}, se determinará automáticamente`);
                                    category = null;
                                }
                                
                                // Intentar leer el archivo de fechas de eventos
                                try {
                                    const eventDatesContent = await readFileWithFetch(`${basePath}/fecha.txt`);
                                    eventDates = parseEventDates(eventDatesContent);
                                } catch (datesError) {
                                    console.warn(`Archivo fecha.txt no encontrado en ${folderName}, se utilizará solo la fecha de subida`);
                                    eventDates = null;
                                }
                                
                                // Intentar leer el archivo de ubicación
                                try {
                                    location = await readFileWithFetch(`${basePath}/ubicacion.txt`);
                                    console.log(`Ubicación cargada para ${folderName}: ${location}`);
                                    
                                    // Intentar leer el archivo de enlace al mapa
                                    try {
                                        mapLink = await readFileWithFetch(`${basePath}/link.txt`);
                                        console.log(`Enlace al mapa cargado para ${folderName}: ${mapLink}`);
                                    } catch (linkError) {
                                        console.warn(`Archivo link.txt no encontrado en ${folderName}, se usará un enlace predeterminado`);
                                        mapLink = "https://maps.app.goo.gl/PqjBFeXsMxhYBziY9"; // Enlace predeterminado
                                    }
                                } catch (locationError) {
                                    console.warn(`Archivo ubicacion.txt no encontrado en ${folderName}, se usará una ubicación predeterminada`);
                                    location = "Ciudad de México, CDMX";
                                    mapLink = "https://maps.app.goo.gl/PqjBFeXsMxhYBziY9"; // Enlace predeterminado
                                }
                            }
                            
                            imagePath = `${basePath}/portada.jpg`;
                            console.log(`Archivos cargados correctamente para ${folderName}`);
                        } catch (fileError) {
                            console.warn(`Error al cargar archivos de ${folderName}:`, fileError);
                            
                            // Generar contenido de ejemplo para demostración
                            console.log(`Generando contenido de ejemplo para ${folderName}`);
                            title = generateExampleTitle(folderName);
                            intro = "Descubre una experiencia única en la Ciudad de México con este evento imperdible. Perfecto para viajeros que buscan sumergirse en la cultura local y crear recuerdos inolvidables durante su estancia.";
                            body = generateExampleBody();
                            imagePath = `${basePath}/portada.jpg`;
                            category = null; // Se determinará automáticamente
                            
                            // Generar fechas de ejemplo para el evento
                            const oneDay = 24 * 60 * 60 * 1000; // Milisegundos en un día
                            const today = new Date();
                            const numDates = Math.floor(Math.random() * 3) + 1; // 1 a 3 fechas
                            
                            if (numDates > 0) {
                                eventDates = [];
                                for (let i = 0; i < numDates; i++) {
                                    const futureDate = new Date(today.getTime() + (i + 1) * 3 * oneDay); // 3, 6, 9 días después
                                    eventDates.push(futureDate);
                                }
                            }
                            
                            // Generar ubicación y enlace de ejemplo
                            location = "Centro Histórico, Ciudad de México";
                            mapLink = "https://maps.app.goo.gl/PqjBFeXsMxhYBziY9";
                        }
                        
                        // Verificar que tenemos todo el contenido necesario
                        if (title && intro && body) {
                            // Si no hay categoría definida, determinarla basado en contenido
                            if (!category || !category.trim() || !blogConfig.categories[category.trim()]) {
                                category = determineCategory(title, body);
                                console.log(`Categoría determinada automáticamente: ${category}`);
                            } else {
                                category = category.trim();
                                console.log(`Categoría leída desde archivo: ${category}`);
                            }
                            
                            // Añadir la publicación a la lista
                            allPosts.push({
                                id: generatePostId(folderName),
                                uploadDate: uploadDate,
                                eventDates: eventDates || [],
                                title: title,
                                intro: intro,
                                body: body,
                                imagePath: imagePath,
                                folderName: folderName,
                                category: category,
                                location: location,
                                mapLink: mapLink
                            });
                            
                            console.log(`Publicación añadida: ${title}`);
                        } else {
                            console.warn(`Falta contenido en la carpeta ${folderName}`);
                        }
                    }
                } catch (error) {
                    console.warn(`Error al procesar la carpeta ${folderName}:`, error);
                }
            }
            
            // Ordenar publicaciones por fecha (más reciente primero)
            allPosts.sort((a, b) => b.uploadDate - a.uploadDate);
            
            console.log(`Se encontraron ${allPosts.length} publicaciones de blog.`);
            return allPosts;
            
        } catch (error) {
            console.error('Error al escanear carpetas del blog:', error);
            throw error;
        }
    }

    /**
     * Procesa el contenido del archivo fecha.txt para obtener las fechas de los eventos
     * Formato esperado: una fecha por línea en formato DD/MM/YYYY o DD-MM-YYYY
     */
    function parseEventDates(content) {
        if (!content || typeof content !== 'string') return null;
        
        const dates = [];
        const lines = content.split('\n').filter(line => line.trim().length > 0);
        
        for (const line of lines) {
            const trimmedLine = line.trim();
            // Intentar diferentes formatos de fecha
            const formats = [
                /^(\d{2})\/(\d{2})\/(\d{4})$/, // DD/MM/YYYY
                /^(\d{2})-(\d{2})-(\d{4})$/,   // DD-MM-YYYY
                /^(\d{2})\/(\d{2})\/(\d{2})$/,  // DD/MM/YY
                /^(\d{2})-(\d{2})-(\d{2})$/     // DD-MM-YY
            ];
            
            for (const format of formats) {
                const match = trimmedLine.match(format);
                if (match) {
                    const day = parseInt(match[1]);
                    const month = parseInt(match[2]) - 1; // Meses en JS son 0-indexed
                    let year = parseInt(match[3]);
                    
                    // Añadir 2000 para años en formato YY
                    if (match[3].length === 2) {
                        year = 2000 + year;
                    }
                    
                    const date = new Date(year, month, day);
                    if (!isNaN(date.getTime())) {
                        dates.push(date);
                    }
                    break;
                }
            }
        }
        
        // Ordenar fechas cronológicamente (de la más cercana a la más lejana)
        dates.sort((a, b) => a - b);
        
        return dates.length > 0 ? dates : null;
    }

    /**
     * Lee un archivo usando la API window.fs
     */
    async function readFileWithFS(filePath) {
        try {
            console.log(`Leyendo archivo con window.fs: ${filePath}`);
            const content = await window.fs.readFile(filePath, { encoding: 'utf8' });
            return processTextContent(content.trim(), getContentType(filePath));
        } catch (error) {
            console.warn(`Error al leer archivo con window.fs: ${filePath}`, error);
            throw error;
        }
    }

    /**
     * Lee un archivo usando fetch
     */
    async function readFileWithFetch(filePath) {
        try {
            console.log(`Leyendo archivo con fetch: ${filePath}`);
            const response = await fetch(filePath);
            if (!response.ok) {
                throw new Error(`HTTP error: ${response.status}`);
            }
            const content = await response.text();
            return processTextContent(content.trim(), getContentType(filePath));
        } catch (error) {
            console.warn(`Error al leer archivo con fetch: ${filePath}`, error);
            throw error;
        }
    }

    /**
     * Determina el tipo de contenido basado en el nombre del archivo
     */
    function getContentType(filePath) {
        if (filePath.includes('titulo.txt')) return 'title';
        if (filePath.includes('intro.txt')) return 'intro';
        if (filePath.includes('cuerpo.txt')) return 'body';
        if (filePath.includes('categoria.txt')) return 'category';
        if (filePath.includes('fecha.txt')) return 'dates';
        if (filePath.includes('ubicacion.txt')) return 'location';
        if (filePath.includes('link.txt')) return 'link';
        return 'other';
    }

    /**
     * Procesa el contenido de texto según su tipo
     */
    function processTextContent(content, contentType) {
        switch(contentType) {
            case 'title':
                return processTitleText(content);
            case 'intro':
                return processIntroText(content);
            case 'body':
                return processBodyText(content);
            case 'category':
                return content.trim().toLowerCase(); // Asegurar que la categoría esté en minúsculas
            case 'dates':
                return content; // El procesamiento de fechas se hace en parseEventDates
            case 'location':
                return content.trim(); // Limpiar espacios para la ubicación
            case 'link':
                return content.trim(); // Limpiar espacios para el enlace
            default:
                return content;
        }
    }

    /**
     * Procesa el texto del título para adaptarlo a su contenedor
     */
    function processTitleText(title) {
        // Limita la longitud del título y añade ellipsis si es necesario
        const maxTitleLength = 70;
        if (title.length > maxTitleLength) {
            return title.substring(0, maxTitleLength) + '...';
        }
        return title;
    }

    /**
     * Procesa el texto de la introducción para adaptarlo a su contenedor
     * con un manejo más inteligente del texto
     */
    function processIntroText(intro) {
        // Eliminar etiquetas HTML si existen
        intro = intro.replace(/<\/?[^>]+(>|$)/g, "");
        
        // Determinar la longitud máxima basada en el contenido
        // Si tiene muchas palabras cortas, permitimos más caracteres
        const words = intro.split(/\s+/);
        const avgWordLength = intro.length / words.length;
        
        // Longitud dinámica basada en la longitud promedio de palabras
        let maxIntroLength = 150;
        
        // Si las palabras son cortas en promedio, permitimos más texto
        if (avgWordLength < 4) {
            maxIntroLength = 180;
        } else if (avgWordLength > 8) {
            // Si hay palabras muy largas, reducimos un poco
            maxIntroLength = 130;
        }
        
        // Limitar la longitud
        if (intro.length > maxIntroLength) {
            // Buscar el último espacio antes del límite para cortar en palabras completas
            const lastSpace = intro.lastIndexOf(' ', maxIntroLength);
            if (lastSpace > maxIntroLength * 0.8) { // Si el espacio está al menos al 80% del máximo
                return intro.substring(0, lastSpace) + '...';
            }
            return intro.substring(0, maxIntroLength) + '...';
        }
        
        return intro;
    }

    /**
     * Procesa el cuerpo del texto para adaptarlo correctamente al modal
     */
    function processBodyText(body) {
        // Asegura que los párrafos estén correctamente estructurados con etiquetas HTML
        if (!body.includes('<p>')) {
            // Divide el texto por líneas en blanco y envuelve cada sección en etiquetas <p>
            const paragraphs = body.split(/\n\s*\n/);
            body = paragraphs.map(p => `<p>${p.trim().replace(/\n/g, '<br>')}</p>`).join('');
        }
        
        // Asegura que las listas estén correctamente formateadas
        body = formatLists(body);
        
        return body;
    }

    /**
     * Formatea listas en el texto si existen
     */
    function formatLists(text) {
        // Detecta y formatea listas con guiones o asteriscos
        const listPattern = /(?:^|\n)((?:[-*•]\s+.+(?:\n|$))+)/gm;
        
        return text.replace(listPattern, function(match, listContent) {
            const items = listContent.split(/\n[-*•]\s+/).filter(item => item.trim().length > 0);
            return '<ul>' + items.map(item => `<li>${item.trim()}</li>`).join('') + '</ul>';
        });
    }

    /**
     * Genera un título de ejemplo basado en el nombre de la carpeta
     */
    function generateExampleTitle(folderName) {
        const categories = ['Cultural', 'Gastronómico', 'Musical'];
        const events = ['Festival', 'Exposición', 'Feria', 'Recorrido', 'Tour', 'Experiencia'];
        const places = ['Centro Histórico', 'Bellas Artes', 'Chapultepec', 'Coyoacán', 'Polanco'];
        
        // Generar un título basado en el nombre de la carpeta
        const categoryIndex = parseInt(folderName.charAt(0)) % categories.length;
        const eventIndex = parseInt(folderName.charAt(3)) % events.length;
        const placeIndex = parseInt(folderName.charAt(5)) % places.length;
        
        return `${events[eventIndex]} ${categories[categoryIndex]} en ${places[placeIndex]}`;
    }

    /**
     * Genera un cuerpo de ejemplo para publicaciones de demostración
     */
    function generateExampleBody() {
        return `
        <p>Te invitamos a descubrir uno de los eventos más emblemáticos que nuestra ciudad ofrece esta temporada. Es una oportunidad perfecta para conocer la riqueza cultural, gastronómica y artística que hace de la Ciudad de México un destino único en el mundo.</p>
        
        <p>El evento se llevará a cabo en una de las zonas más emblemáticas de la ciudad, con fácil acceso mediante transporte público y a tan solo 15 minutos de nuestro hostal BEMARO.</p>
        
        <p>Durante tu visita podrás disfrutar de:</p>
        <ul>
            <li>Presentaciones en vivo de artistas locales</li>
            <li>Degustación de platillos tradicionales</li>
            <li>Talleres interactivos para todas las edades</li>
            <li>Exposiciones de artesanías mexicanas</li>
            <li>Recorridos guiados por expertos en la materia</li>
        </ul>
        
        <p>El costo de entrada oscila entre $100 y $250 MXN, dependiendo de las actividades en las que desees participar. Algunos espacios requieren reservación previa, por lo que te recomendamos planificar tu visita con anticipación.</p>
        
        <p>Si estás hospedado en BEMARO, pregunta por nuestros descuentos especiales y servicios de transporte compartido hasta el lugar del evento.</p>
        
        <p>Para más información, acércate a nuestra recepción donde con gusto resolveremos todas tus dudas.</p>
        `;
    }

    /**
     * Genera un ID único para cada publicación basado en su carpeta
     */
    function generatePostId(folderName) {
        return `post-${folderName}`;
    }

    /**
     * Determina la categoría de una publicación basada en su contenido
     * En un entorno real, esto podría ser un campo en una base de datos
     */
    function determineCategory(title, body) {
        title = title.toLowerCase();
        body = body.toLowerCase();
        
        // Palabras clave para categorías
        const culturalKeywords = ['cultural', 'museo', 'exposición', 'arte', 'historia', 'tour', 'recorrido'];
        const gastronomicKeywords = ['gastronómica', 'comida', 'cocina', 'sabores', 'degustación', 'mezcal', 'restaurante'];
        const musicKeywords = ['música', 'concierto', 'festival', 'jazz', 'clásica', 'banda', 'orquesta'];
        
        // Verificar contenido para determinar categoría
        const content = title + ' ' + body;
        
        if (culturalKeywords.some(keyword => content.includes(keyword))) {
            return 'cultural';
        } else if (gastronomicKeywords.some(keyword => content.includes(keyword))) {
            return 'gastronomico';
        } else if (musicKeywords.some(keyword => content.includes(keyword))) {
            return 'musica';
        }
        
        // Categoría predeterminada basada en el contenido de ejemplo
        return ['cultural', 'gastronomico', 'musica'][Math.floor(Math.random() * 3)];
    }

    /**
     * Convierte un nombre de carpeta con formato dd-mm-aa a objeto Date
     */
    function parsePostDate(folderName) {
        // Validar formato
        const regex = /^(\d{2})-(\d{2})-(\d{2})$/;
        const match = folderName.match(regex);
        
        if (match) {
            const day = parseInt(match[1]);
            const month = parseInt(match[2]) - 1; // Meses en JS son 0-indexed
            const year = parseInt('20' + match[3]); // Asumiendo años 2000+
            
            return new Date(year, month, day);
        }
        
        return null;
    }

    /**
     * Verifica si una imagen existe
     */
    function checkImageExists(url) {
        return new Promise(resolve => {
            console.log(`Verificando imagen: ${url}`);
            const img = new Image();
            
            img.onload = () => {
                console.log(`Imagen cargada correctamente: ${url}`);
                resolve(true);
            };
            
            img.onerror = () => {
                console.warn(`Error al cargar imagen: ${url}`);
                resolve(false);
            };
            
            img.src = url;
        });
    }
    
    /**
     * Crea un archivo index.json para el blog
     * Este paso es solo informativo, ya que en un entorno real,
     * este archivo debería crearse en el servidor
     */
    function createIndexJsonInfo() {
        console.log(`
IMPORTANTE: Para que el blog funcione correctamente, necesitas crear un archivo index.json
en la carpeta 'blog' con la siguiente estructura:

{
    "directories": [
        "01-04-25",
        "28-03-25",
        "21-03-25",
        "15-03-25",
        "08-03-25"
        // ... otras carpetas de blog
    ]
}

Cada entrada debe ser el nombre exacto de una carpeta con formato dd-mm-aa
que contenga los archivos portada.jpg, titulo.txt, intro.txt, cuerpo.txt y opcionalmente categoria.txt, fecha.txt, ubicacion.txt y link.txt.

El archivo fecha.txt debe contener las fechas del evento, una por línea, en formato DD/MM/YYYY o DD-MM-YYYY.
El archivo ubicacion.txt debe contener la ubicación del evento.
El archivo link.txt debe contener el enlace al mapa.

Alternativamente, puedes habilitar CORS en tu servidor web para permitir
la lectura directa de archivos locales.
        `);
    }

    /**
     * Aplica filtros actuales a las publicaciones
     */
    function applyFilters() {
        filteredPosts = [...allPosts];
        
        // Aplicar filtro de categoría
        if (activeFilter !== 'all') {
            filteredPosts = filteredPosts.filter(post => post.category === activeFilter);
        }
        
        // Aplicar filtro de búsqueda
        if (searchQuery.trim() !== '') {
            const query = searchQuery.toLowerCase();
            filteredPosts = filteredPosts.filter(post => 
                post.title.toLowerCase().includes(query) || 
                post.intro.toLowerCase().includes(query) || 
                post.body.toLowerCase().includes(query)
            );
        }
        
        // Resetear estado de visualización
        displayedPosts = 0;
        blogGrid.empty();
        
        // Mostrar mensaje si no hay resultados
        if (filteredPosts.length === 0) {
            showNoResultsMessage();
            loadMoreBtn.addClass('hidden');
        } else {
            loadMoreBtn.removeClass('hidden');
        }
    }

    /**
     * Carga publicaciones en el grid principal
     */
    function loadPosts(count) {
        if (isLoading) return;
        
        isLoading = true;
        showLoader();
        
        setTimeout(() => {
            const startIndex = displayedPosts;
            const endIndex = Math.min(startIndex + count, filteredPosts.length);
            
            // Ocultar botón "Cargar más" si no hay más publicaciones
            if (endIndex >= filteredPosts.length) {
                loadMoreBtn.addClass('hidden');
            } else {
                loadMoreBtn.removeClass('hidden');
            }
            
            // Añadir publicaciones al grid con aparición secuencial
            for (let i = startIndex; i < endIndex; i++) {
                const post = filteredPosts[i];
                const delay = (i - startIndex) * 100;
                
                setTimeout(() => {
                    addPostToGrid(post);
                }, delay);
            }
            
            displayedPosts = endIndex;
            
            // Terminar la carga después de añadir todas las publicaciones
            setTimeout(() => {
                hideLoader();
                isLoading = false;
            }, (endIndex - startIndex) * 100 + 200);
            
        }, 500);
    }

    /**
     * Carga las publicaciones recientes en el sidebar
     */
    function loadRecentPosts() {
        sidebarContent.empty();
        
        // Tomar las primeras publicaciones (más recientes)
        const recentPosts = allPosts.slice(0, blogConfig.maxRecentPosts);
        
        if (recentPosts.length > 0) {
            for (let i = 0; i < recentPosts.length; i++) {
                const post = recentPosts[i];
                
                // Añadir con animación secuencial
                setTimeout(() => {
                    addPostToSidebar(post);
                }, i * 100);
            }
        } else {
            sidebarContent.html('<p class="no-recent-posts">No hay publicaciones recientes.</p>');
        }
    }

    /**
     * Añade una publicación al grid principal con mejor manejo del contenido
     */
    function addPostToGrid(post) {
        const formattedUploadDate = formatDate(post.uploadDate, blogConfig.uploadDateFormat);
        const hasEventDates = post.eventDates && post.eventDates.length > 0;
        const categoryInfo = blogConfig.categories[post.category] || { name: 'General', icon: 'fas fa-tag' };
        
        // Procesar el título y la introducción para adaptarse mejor
        const processedTitle = post.title.length > 60 ? post.title.substring(0, 57) + '...' : post.title;
        
        // Preparar el HTML para fechas (ahora en el lado derecho)
        let datesHTML = `
            <div class="blog-post-dates">
                <div class="blog-post-upload-date">
                    <i class="far fa-calendar-alt"></i>
                    Publicado: ${formattedUploadDate}
                </div>
        `;
        
        if (hasEventDates) {
            const firstDate = formatDate(post.eventDates[0], blogConfig.eventDateFormat);
            const hasMultipleDates = post.eventDates.length > 1;
            
            datesHTML += `
                <div class="blog-post-event-date">
                    <i class="far fa-calendar-check"></i>
                    ${firstDate}
                    ${hasMultipleDates ? '<span class="multi-date-indicator"><i class="fas fa-ellipsis-h"></i></span>' : ''}
                </div>
            `;
        }
        
        datesHTML += `</div>`;
        
        // Preparar el HTML del footer con la ubicación y el botón
        let footerHTML = `
            <div class="blog-post-footer">
                <div class="blog-post-location">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${post.location}</span>
                </div>
                <a href="#" class="blog-post-btn">
                    Leer más <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        `;
        
        const postElement = $(`
            <div class="blog-post" data-id="${post.id}" data-category="${post.category}">
                <div class="blog-post-img-container">
                    <img src="${post.imagePath}" alt="${post.title}" class="blog-post-img">
                    <div class="blog-post-category">${categoryInfo.name}</div>
                </div>
                <div class="blog-post-content">
                    <div class="blog-post-header">
                        <h3 class="blog-post-title">${processedTitle}</h3>
                        ${datesHTML}
                    </div>
                    <p class="blog-post-excerpt text-multiline-truncate">${post.intro}</p>
                    ${footerHTML}
                </div>
            </div>
        `);
        
        blogGrid.append(postElement);
        
        // Evento para abrir el modal con la publicación completa
        postElement.find('.blog-post-btn').on('click', function(e) {
            e.preventDefault();
            openPostModal(post);
        });
        
        // También hacer clic en el título o la imagen para abrir el modal
        postElement.find('.blog-post-title, .blog-post-img').on('click', function() {
            openPostModal(post);
        });
        
        // Mostrar tooltip con todas las fechas si hay múltiples
        if (hasEventDates && post.eventDates.length > 1) {
            postElement.find('.multi-date-indicator').on('click', function(e) {
                e.stopPropagation();
                showEventDatesPopup(post, $(this));
            });
        }
    }

    /**
     * Muestra un popup con todas las fechas del evento
     */
    function showEventDatesPopup(post, targetElement) {
        // Eliminar cualquier popup existente
        $('.dates-dropdown').remove();
        
        // Crear el popup
        const datesDropdown = $('<div class="dates-dropdown"></div>');
        
        // Añadir todas las fechas
        post.eventDates.forEach((date, index) => {
            const formattedDate = formatDate(date, blogConfig.eventDateFormat);
            const dateItem = $(`
                <div class="dropdown-date">
                    <i class="far fa-calendar-check"></i>
                    ${formattedDate}
                </div>
            `);
            datesDropdown.append(dateItem);
        });
        
        // Posicionar y mostrar el popup
        const parent = targetElement.closest('.blog-post-event-date');
        parent.append(datesDropdown);
        setTimeout(() => {
            datesDropdown.addClass('show');
        }, 10);
        
        // Cerrar el popup al hacer clic fuera
        $(document).one('click', function() {
            datesDropdown.removeClass('show');
            setTimeout(() => {
                datesDropdown.remove();
            }, 300);
        });
    }

    /**
     * Añade una publicación al sidebar
     */
    function addPostToSidebar(post) {
        const formattedUploadDate = formatDate(post.uploadDate, blogConfig.uploadDateFormat);
        const hasEventDates = post.eventDates && post.eventDates.length > 0;
        
        // Siempre mostrar la fecha de carga, independientemente de si hay fechas de evento
        let dateInfo = formattedUploadDate;
        
        const sidebarEvent = $(`
            <div class="sidebar-event" data-id="${post.id}">
                <img src="${post.imagePath}" alt="${post.title}" class="sidebar-event-img">
                <div class="sidebar-event-content">
                    <h4 class="sidebar-event-title text-truncate">${post.title}</h4>
                    <div class="sidebar-event-date">
                        <i class="far fa-calendar-alt"></i>
                        ${dateInfo}
                    </div>
                </div>
            </div>
        `);
        
        sidebarContent.append(sidebarEvent);
        
        // Evento para abrir el modal con la publicación completa
        sidebarEvent.on('click', function() {
            openPostModal(post);
            
            // Marcar como activo en el sidebar
            $('.sidebar-event').removeClass('active');
            $(this).addClass('active');
        });
    }

    /**
     * Abre el modal con la publicación completa
     */
    function openPostModal(post) {
        const formattedUploadDate = formatDate(post.uploadDate, blogConfig.uploadDateFormat);
        const hasEventDates = post.eventDates && post.eventDates.length > 0;
        const categoryInfo = blogConfig.categories[post.category] || { name: 'General', icon: 'fas fa-tag' };
        
        // Preparar las fechas para el modal
        let datesHTML = `
            <div class="modal-dates">
                <div class="modal-upload-date">
                    <i class="far fa-calendar-alt"></i>
                    Publicado: ${formattedUploadDate}
                </div>
        `;
        
        if (hasEventDates) {
            datesHTML += `<div class="modal-event-dates">`;
            
            post.eventDates.forEach(date => {
                const formattedDate = formatDate(date, blogConfig.eventDateFormat);
                datesHTML += `
                    <div class="modal-event-date">
                        <i class="far fa-calendar-check"></i>
                        ${formattedDate}
                    </div>
                `;
            });
            
            datesHTML += `</div>`;
        }
        
        // Añadir ubicación al modal
        if (post.location) {
            datesHTML += `
                <div class="modal-location">
                    <i class="fas fa-map-marker-alt"></i>
                    Ubicación: ${post.location}
                </div>
            `;
        }
        
        datesHTML += `</div>`;
        
        // Llenar contenido del modal
        blogModal.find('.modal-image img').attr('src', post.imagePath).attr('alt', post.title);
        blogModal.find('.modal-title').text(post.title);
        blogModal.find('.modal-meta').html(datesHTML);
        blogModal.find('.modal-category').html(`<i class="${categoryInfo.icon}"></i> ${categoryInfo.name}`);
        blogModal.find('.modal-text').html(post.body).addClass('modal-content-wrapper');
        
        // Actualizar el footer del modal para incluir el botón del mapa
        blogModal.find('.modal-footer').html(`
            <button class="modal-btn map" onclick="window.open('${post.mapLink}', '_blank')">
                <i class="fas fa-map-marked-alt"></i> Ver en el mapa
            </button>
            <button class="modal-btn close">
                <i class="fas fa-times"></i> Cerrar
            </button>
        `);
        
        // Volver a añadir el evento para cerrar el modal
        blogModal.find('.modal-btn.close').on('click', function() {
            blogModal.removeClass('show');
            $('body').css('overflow', '');
        });
        
        // Mostrar modal
        blogModal.addClass('show');
        $('body').css('overflow', 'hidden');
    }

    /**
     * Inicializa eventos del blog
     */
    function initEvents() {
        // Botón "Cargar más" con feedback visual mejorado
        loadMoreBtn.on('click', function() {
            // Efecto de pulsación
            $(this).css({
                'transform': 'scale(0.95)',
                'box-shadow': '0 5px 15px rgba(0, 0, 0, 0.1)'
            });
            
            // Restaurar después de un breve retraso
            setTimeout(() => {
                $(this).css({
                    'transform': '',
                    'box-shadow': ''
                });
                
                // Cargar más publicaciones
                loadPosts(blogConfig.loadMoreCount);
            }, 150);
        });
        
        // Cerrar modal
        blogModal.find('.modal-close, .modal-btn.close').on('click', function() {
            blogModal.removeClass('show');
            $('body').css('overflow', '');
        });
        
        // Cerrar modal con Escape
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && blogModal.hasClass('show')) {
                blogModal.removeClass('show');
                $('body').css('overflow', '');
            }
        });
        
        // Filtros de categoría
        filterBtns.on('click', function() {
            const newFilter = $(this).data('filter');
            
            if (newFilter !== activeFilter) {
                activeFilter = newFilter;
                
                // Actualizar UI
                filterBtns.removeClass('active');
                $(this).addClass('active');
                
                // Aplicar filtros
                applyFilters();
                loadPosts(blogConfig.initialLoadCount);
            }
        });
        
        // Búsqueda
        searchBtn.on('click', function() {
            const newQuery = searchInput.val();
            
            if (newQuery !== searchQuery) {
                searchQuery = newQuery;
                applyFilters();
                loadPosts(blogConfig.initialLoadCount);
            }
        });
        
        // Búsqueda al presionar Enter
        searchInput.on('keypress', function(e) {
            if (e.which === 13) {
                const newQuery = searchInput.val();
                
                if (newQuery !== searchQuery) {
                    searchQuery = newQuery;
                    applyFilters();
                    loadPosts(blogConfig.initialLoadCount);
                }
            }
        });
        
        // IMPORTANTE: Se ha eliminado el código de scroll infinito para cumplir con los requisitos
        // Los elementos adicionales sólo se cargarán al hacer clic en el botón "Cargar más"
        
        // Cerrar cualquier dropdown de fechas al hacer clic en el documento
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.date-toggle, .multi-date-indicator').length) {
                $('.dates-dropdown').removeClass('show');
            }
        });
        
        // Verificar si hay un ID de publicación en la URL
        const urlParams = new URLSearchParams(window.location.search);
        const postId = urlParams.get('post');
        
        if (postId) {
            const post = allPosts.find(p => p.id === postId);
            if (post) {
                // Abrir modal con la publicación
                setTimeout(() => {
                    openPostModal(post);
                    
                    // Marcar como activo en el sidebar si existe
                    $(`.sidebar-event[data-id="${postId}"]`).addClass('active');
                }, 500);
            }
        }
    }

    /**
     * Muestra el loader
     */
    function showLoader() {
        blogLoader.removeClass('hidden');
    }

    /**
     * Oculta el loader
     */
    function hideLoader() {
        blogLoader.addClass('hidden');
    }

    /**
     * Muestra un mensaje cuando no hay publicaciones
     */
    function showEmptyMessage() {
        blogGrid.html(`
            <div class="no-results">
                <i class="far fa-newspaper"></i>
                <h3>No hay publicaciones disponibles</h3>
                <p>Por el momento no hay eventos publicados. Por favor, vuelve más tarde.</p>
            </div>
        `);
        
        loadMoreBtn.addClass('hidden');
    }

    /**
     * Muestra un mensaje cuando no hay resultados de búsqueda o filtrado
     */
    function showNoResultsMessage() {
        blogGrid.html(`
            <div class="no-results">
                <i class="fas fa-search"></i>
                <h3>No se encontraron resultados</h3>
                <p>No hay eventos que coincidan con tu búsqueda. Intenta con otros términos o filtros.</p>
            </div>
        `);
    }

    /**
     * Muestra un mensaje de error
     */
    function showErrorMessage(message) {
        blogGrid.html(`
            <div class="no-results">
                <i class="fas fa-exclamation-circle"></i>
                <h3>Ha ocurrido un error</h3>
                <p>${message}</p>
                <button class="blog-post-btn retry">Reintentar</button>
            </div>
        `);
        
        blogGrid.find('.retry').on('click', function() {
            initBlog();
        });
        
        loadMoreBtn.addClass('hidden');
    }

    /**
     * Formatea una fecha para mostrar
     */
    function formatDate(date, formatOptions) {
        return date.toLocaleDateString('es-ES', formatOptions);
    }
});