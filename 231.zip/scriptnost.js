// Script específico para la página Nosotros

document.addEventListener('DOMContentLoaded', function() {
    // Efecto parallax para el hero
    const heroSection = document.querySelector('.nosotros-hero');
    
    window.addEventListener('scroll', function() {
        if (heroSection) {
            const scrollPosition = window.scrollY;
            // Efecto parallax suave para el fondo
            heroSection.style.backgroundPosition = `center ${scrollPosition * 0.4}px`;
        }
    });
    
    // Inicializar Swiper para valores
    initValuesSwiper();
    
    // Inicializar Swiper para equipo
    initTeamSwiper();
    
    // Animación para las tarjetas de valores al hacer hover
    const valueCards = document.querySelectorAll('.value-card');
    
    valueCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            const icon = this.querySelector('.value-icon i');
            if (icon) {
                icon.classList.add('fa-beat');
                setTimeout(() => {
                    icon.classList.remove('fa-beat');
                }, 800);
            }
        });
    });
    
    // Redirección del botón CTA
    const ctaButton = document.querySelector('.nosotros-cta-btn');
    if (ctaButton) {
        ctaButton.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = 'index.html#habitaciones';
        });
    }
});

// Inicializar Swiper para la sección de valores
function initValuesSwiper() {
    // Primero, crear y añadir el indicador de progreso personalizado si no existe
    createProgressElements('values');
    
    // Verifica si el elemento Swiper existe
    const swiperContainer = document.querySelector('.swiper-values');
    if (!swiperContainer) return; // No continúa si no existe el contenedor
    
    // Inicializa el Swiper de valores
    const valuesSwiper = new Swiper('.swiper-values', {
        slidesPerView: 1,
        spaceBetween: 30,
        centeredSlides: true,
        loop: false,
        speed: 800,
        grabCursor: true,
        
        // Eliminar efecto coverflow
        effect: 'slide', // Cambiado de 'coverflow' a 'slide' estándar
        
        // Paginación estándar
        pagination: {
            el: '.swiper-values .swiper-pagination',
            clickable: true,
            renderBullet: function (index, className) {
                return '<span class="' + className + '"><span class="pagination-indicator"></span></span>';
            },
        },
        
        // Botones de navegación
        navigation: {
            nextEl: '.swiper-values .swiper-button-next',
            prevEl: '.swiper-values .swiper-button-prev',
        },
        
        // Adaptación responsiva
        breakpoints: {
            768: {
                slidesPerView: 1.5,
            },
            992: {
                slidesPerView: 2.5,
            },
            1200: {
                slidesPerView: 3,
            }
        },
        
        // Eventos para actualizar el indicador de progreso
        on: {
            init: function() {
                safeUpdateProgress(this, 'values');
            },
            slideChange: function() {
                safeUpdateProgress(this, 'values');
            },
            resize: function() {
                safeUpdateProgress(this, 'values');
            }
        }
    });
}

// Inicializar Swiper para la sección de equipo
function initTeamSwiper() {
    // Primero, crear y añadir el indicador de progreso personalizado si no existe
    createProgressElements('team');
    
    // Verifica si el elemento Swiper existe
    const swiperContainer = document.querySelector('.swiper-team');
    if (!swiperContainer) return; // No continúa si no existe el contenedor
    
    // Inicializa el Swiper de equipo
    const teamSwiper = new Swiper('.swiper-team', {
        slidesPerView: 1,
        spaceBetween: 30,
        centeredSlides: true,
        loop: false,
        speed: 800,
        grabCursor: true,
        
        // Eliminar efecto coverflow
        effect: 'slide', // Cambiado de 'coverflow' a 'slide' estándar
        
        // Paginación estándar
        pagination: {
            el: '.swiper-team .swiper-pagination',
            clickable: true,
            renderBullet: function (index, className) {
                return '<span class="' + className + '"><span class="pagination-indicator"></span></span>';
            },
        },
        
        // Botones de navegación
        navigation: {
            nextEl: '.swiper-team .swiper-button-next',
            prevEl: '.swiper-team .swiper-button-prev',
        },
        
        // Adaptación responsiva
        breakpoints: {
            768: {
                slidesPerView: 1.5,
            },
            992: {
                slidesPerView: 2,
            },
            1200: {
                slidesPerView: 3,
            }
        },
        
        // Eventos para actualizar el indicador de progreso
        on: {
            init: function() {
                safeUpdateProgress(this, 'team');
            },
            slideChange: function() {
                safeUpdateProgress(this, 'team');
            },
            resize: function() {
                safeUpdateProgress(this, 'team');
            }
        }
    });
}

// Función para crear los elementos de progreso de manera segura
function createProgressElements(type) {
    // Verificar si existe el contenedor Swiper
    const swiperContainer = document.querySelector(`.swiper-${type}`);
    if (!swiperContainer) return; // No continúa si no existe el contenedor
    
    // Verificar si ya existe el indicador
    if (!document.querySelector(`.${type}-progress .progress-bar`)) {
        // Si no existe la barra de progreso, actualizar la estructura
        const progressIndicator = document.querySelector(`.${type}-progress`);
        if (progressIndicator) {
            progressIndicator.innerHTML = 
                '<div class="progress-bar-container"><div class="progress-bar"></div></div>' +
                '<div class="swiper-progress-text"><span class="current">1</span><span class="separator">/</span><span class="total">5</span></div>';
        }
    }
}

// Función segura para actualizar el indicador de progreso
function safeUpdateProgress(swiper, type) {
    try {
        updateSwiperProgress(swiper, type);
    } catch (error) {
        console.warn(`No se pudo actualizar el progreso del Swiper ${type}:`, error);
    }
}

// Función para actualizar el indicador visual de progreso con verificaciones adicionales
function updateSwiperProgress(swiper, type) {
    if (!swiper || !swiper.slides || swiper.slides.length === 0) return;
    
    const totalSlides = swiper.slides.length;
    const activeIndex = swiper.realIndex;
    
    // Evitar división por cero
    const divisor = totalSlides > 1 ? (totalSlides - 1) : 1;
    const progressPercentage = (activeIndex / divisor) * 100;
    
    // Verificar que existan los elementos antes de manipularlos
    const progressBar = document.querySelector(`.${type}-progress .progress-bar`);
    const progressText = document.querySelector(`.${type}-progress .swiper-progress-text`);
    
    if (progressBar) {
        progressBar.style.width = progressPercentage + '%';
    }
    
    if (progressText) {
        progressText.innerHTML = 
            '<span class="current">' + (activeIndex + 1) + '</span>' + 
            '<span class="separator">/</span>' + 
            '<span class="total">' + totalSlides + '</span>';
    }
}