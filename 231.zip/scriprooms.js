// Script para la sección de habitaciones con Swiper
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar el componente Swiper para las habitaciones
    initRoomsSwiper();
});

function initRoomsSwiper() {
    // Verificar si existe el elemento con la clase swiper-rooms
    if (!document.querySelector('.swiper-rooms')) return;
    
    // Inicializar Swiper con configuración actualizada
    const swiper = new Swiper('.swiper-rooms', {
        // Configuración básica
        slidesPerView: 1, // Vista móvil por defecto
        spaceBetween: 20,
        loop: true,
        speed: 700,
        grabCursor: true,
        
        // Se eliminó la configuración de autoplay para que el carrusel no se mueva automáticamente
        
        // Eliminar efecto de escala
        effect: 'slide', // Usar slide simple en lugar de efectos complejos
        
        // Opciones de centrado mejoradas
        centeredSlides: true, // Centrar el slide activo
        centerInsufficientSlides: true, // Centrar slides cuando no hay suficientes
        
        // Navegación
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        
        // Paginación
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
            type: 'bullets',
        },
        
        // Scrollbar opcional
        scrollbar: {
            el: '.swiper-scrollbar',
            draggable: true,
        },
        
        // Breakpoints responsivos actualizados
        breakpoints: {
            576: {
                slidesPerView: 1.2,
                spaceBetween: 15,
                centeredSlides: true,
            },
            768: {
                slidesPerView: 1.5, // Reducido de 2 para mejor centrado
                spaceBetween: 20,
                centeredSlides: true,
            },
            992: {
                slidesPerView: 2.2, // Reducido de 2.5 para mejor disposición
                spaceBetween: 30,
                centeredSlides: true,
            },
            1200: {
                slidesPerView: 3,
                spaceBetween: 40,
                centeredSlides: false, // No es necesario centrar en pantallas grandes
            },
        },
        
        // Accesibilidad
        a11y: {
            prevSlideMessage: 'Habitación anterior',
            nextSlideMessage: 'Siguiente habitación',
            firstSlideMessage: 'Esta es la primera habitación',
            lastSlideMessage: 'Esta es la última habitación',
        },
    });
    
    // Asegurar el posicionamiento adecuado de navegación y paginación
    const updateSwiperLayout = () => {
        // Forzar a swiper a actualizar layout
        swiper.update();
        
        // Actualizar posiciones de slides si es necesario
        setTimeout(() => {
            swiper.updateSlides();
            swiper.updateProgress();
            swiper.updateSlidesClasses();
        }, 100);
    };
    
    // Ejecutar al cargar y al redimensionar
    updateSwiperLayout();
    window.addEventListener('resize', updateSwiperLayout);
    
    // Desactivar cualquier animación de progreso
    const progressIndicator = document.querySelector('.swiper-progress-indicator');
    if (progressIndicator) {
        progressIndicator.style.display = 'none';
    }
    
    // Asegurar que no hay efecto visual al cambiar entre diapositivas
    const swiperSlides = document.querySelectorAll('.swiper-rooms .swiper-slide');
    swiperSlides.forEach(slide => {
        slide.style.transform = 'scale(1)';
    });
}