/**
 * BEMARO - Galería Elegante con Visor Personalizado
 * Prevención de duplicados y efectos visuales premium
 * Método de búsqueda de imágenes actualizado para usar index.json
 */

$(document).ready(function() {
    // Configuración
    const galleryConfig = {
        rootFolder: 'imagenes/galeria', // Carpeta principal de imágenes
        initialLoadCount: 12, // Número inicial de imágenes a cargar
        loadMoreCount: 6, // Número de imágenes a cargar con "cargar más"
        minInitialImages: 12, // Mínimo para llenar la galería
        // Extensiones comunes de imágenes
        extensions: ['jpg', 'jpeg', 'png', 'webp', 'gif']
    };

    // Variables globales
    let allImages = [];
    let processedImages = new Set(); // Para evitar imágenes duplicadas
    let displayedImages = 0;
    let isLoading = false;
    let totalImagesFound = 0;
    let scanComplete = false;
    let currentLightboxIndex = 0;

    // Referencias a elementos DOM
    const galleryGrid = $('#gallery-grid');
    const galleryLoader = $('.gallery-loader');
    const loadMoreBtn = $('.load-more-btn');
    const gallerySection = $('.gallery-section');
    const heroSection = $('.gallery-hero');
    const customLightbox = $('.custom-lightbox');
    const lightboxImg = $('.lightbox-img');
    const lightboxClose = $('.lightbox-close');
    const lightboxPrev = $('.lightbox-prev');
    const lightboxNext = $('.lightbox-next');
    const lightboxCounter = $('.lightbox-counter');
    const lightboxThumbnails = $('.lightbox-thumbnails');
    const lightboxLoader = $('.lightbox-loader');

    // Efecto Parallax en la imagen de fondo
    $(window).on('scroll', function() {
        const scrollTop = $(this).scrollTop();
        const heroHeight = heroSection.height();
        
        if (scrollTop <= heroHeight) {
            const parallaxValue = scrollTop * 0.4;
            $('.gallery-hero-bg').css('transform', `scale(1.1) translateY(${parallaxValue}px)`);
            $('.gallery-hero-content').css('transform', `translateY(${scrollTop * 0.2}px)`);
        }
    });

    // Observer de Intersección para detectar cuando la sección es visible
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    gallerySection.addClass('section-visible');
                    observer.unobserve(entry.target);
                    
                    // Iniciar carga de imágenes después de mostrar animaciones
                    setTimeout(initGallery, 500);
                }
            });
        }, { threshold: 0.1 });

        // Observar la sección de galería
        observer.observe(document.querySelector('.gallery-section'));
    } else {
        // Fallback para navegadores que no soportan IntersectionObserver
        gallerySection.addClass('section-visible');
        initGallery();
    }

    // Mostrar información sobre el archivo index.json necesario
    createIndexJsonInfo();

    /**
     * Inicializa la galería y comienza la detección de imágenes
     */
    function initGallery() {
        showLoader();
        
        // Comenzar a escanear las carpetas en busca de imágenes
        scanImagesFromRoot().then(() => {
            hideLoader();
            
            if (allImages.length > 0) {
                // Cargar un mínimo de imágenes para llenar la galería
                const initialCount = Math.max(galleryConfig.initialLoadCount, 
                                           Math.min(allImages.length, galleryConfig.minInitialImages));
                loadImages(initialCount);
                
                // Inicializar eventos
                initEvents();
            } else {
                showEmptyMessage();
            }
        }).catch(error => {
            console.error('Error al cargar la galería:', error);
            showErrorMessage('No se pudieron cargar las imágenes de la galería. Por favor, intenta de nuevo más tarde.');
        });
    }

    /**
     * Escanea la carpeta raíz en busca de imágenes usando un archivo index.json
     * Similar al método usado en el blog
     */
    async function scanImagesFromRoot() {
        allImages = [];
        processedImages.clear(); // Reiniciar conjunto de imágenes procesadas
        scanComplete = false;
        totalImagesFound = 0;
        
        try {
            console.log('Iniciando escaneo de imágenes en:', galleryConfig.rootFolder);
            
            // Intentar leer el archivo index.json con las rutas de las imágenes
            let imagePaths = [];
            
            try {
                if (typeof window.fs !== 'undefined' && window.fs.readFile) {
                    console.log('Usando window.fs.readFile para leer index.json');
                    
                    // Intentar leer un archivo de índice que liste las imágenes
                    const indexContent = await window.fs.readFile(`${galleryConfig.rootFolder}/index.json`, { encoding: 'utf8' });
                    const indexData = JSON.parse(indexContent);
                    imagePaths = indexData.images || [];
                    
                    console.log('Imágenes encontradas en index.json:', imagePaths);
                } else {
                    // Intentar cargar un archivo index.json manualmente
                    console.log('Intentando cargar index.json mediante fetch');
                    const response = await fetch(`${galleryConfig.rootFolder}/index.json`);
                    if (response.ok) {
                        const indexData = await response.json();
                        imagePaths = indexData.images || [];
                        console.log('Imágenes encontradas en index.json mediante fetch:', imagePaths);
                    } else {
                        throw new Error('No se pudo cargar index.json');
                    }
                }
            } catch (err) {
                console.warn('Error al leer el índice de imágenes:', err);
                console.log('Usando lista de imágenes de ejemplo para demostración');
                
                // Lista de ejemplo para demostración
                imagePaths = [
                    '1.jpg', '2.jpg', '3.jpg', '4.jpg', '5.jpg',
                    '6.jpg', '7.jpg', '8.jpg', '9.jpg', '10.jpg',
                    '11.jpg', '12.jpg', '13.jpg', '14.jpg', '15.jpg',
                    '16.jpg', '17.jpg', '18.jpg', '19.jpg', '20.jpg'
                ];
            }
            
            console.log('Rutas de imágenes a procesar:', imagePaths);
            
            // Para cada imagen en la lista, procesarla
            for (const imagePath of imagePaths) {
                try {
                    // Construir la ruta completa
                    const fullPath = `${galleryConfig.rootFolder}/${imagePath}`;
                    console.log(`Procesando imagen: ${fullPath}`);
                    
                    // Generar un hash simple basado en la ruta de la imagen
                    const imageHash = generateImageHash(fullPath);
                    
                    // Verificar si ya hemos procesado esta imagen
                    if (!processedImages.has(imageHash)) {
                        // Verificar si la imagen existe
                        const exists = await checkImageExists(fullPath);
                        
                        if (exists) {
                            processedImages.add(imageHash);
                            totalImagesFound++;
                            
                            // Determinar la orientación de la imagen
                            const orientation = await determineImageOrientation(fullPath);
                            
                            // Añadir la imagen al array
                            allImages.push({
                                path: fullPath,
                                thumbPath: fullPath, // Misma ruta para miniaturas
                                type: orientation,
                                id: `img-${imageHash}`, // ID único basado en hash
                                index: totalImagesFound - 1
                            });
                            
                            console.log(`Imagen añadida: ${fullPath}, orientación: ${orientation}`);
                        } else {
                            console.warn(`Imagen no encontrada: ${fullPath}`);
                        }
                    } else {
                        console.log(`Imagen duplicada detectada: ${fullPath}`);
                    }
                } catch (error) {
                    console.warn(`Error al procesar la imagen ${imagePath}:`, error);
                }
            }
            
            // Ordenar las imágenes de forma aleatoria para mejor distribución visual
            shuffleArray(allImages);
            
            scanComplete = true;
            console.log(`Escaneo completado. ${totalImagesFound} imágenes únicas encontradas.`);
            
            return allImages;
            
        } catch (error) {
            console.error('Error al escanear imágenes de la galería:', error);
            throw error;
        }
    }

    /**
     * Lee un archivo usando la API window.fs
     */
    async function readFileWithFS(filePath) {
        try {
            console.log(`Leyendo archivo con window.fs: ${filePath}`);
            const content = await window.fs.readFile(filePath, { encoding: 'utf8' });
            return content.trim();
        } catch (error) {
            console.warn(`Error al leer archivo con window.fs: ${filePath}`, error);
            throw error;
        }
    }

    /**
     * Lee un archivo usando fetch
     */
    async function readFileWithFetch(filePath) {
        try {
            console.log(`Leyendo archivo con fetch: ${filePath}`);
            const response = await fetch(filePath);
            if (!response.ok) {
                throw new Error(`HTTP error: ${response.status}`);
            }
            const content = await response.text();
            return content.trim();
        } catch (error) {
            console.warn(`Error al leer archivo con fetch: ${filePath}`, error);
            throw error;
        }
    }

    /**
     * Genera un hash simple basado en la ruta de la imagen
     * Esto ayuda a identificar imágenes duplicadas, incluso si tienen nombres diferentes
     */
    function generateImageHash(path) {
        // Extraer el nombre base sin extensión
        const baseNameMatch = path.match(/\/([^\/]+)\.[^\.]+$/);
        let baseName = baseNameMatch ? baseNameMatch[1] : path;
        
        // En una implementación real, haríamos un hash del contenido real de la imagen
        // Para este ejemplo simplificado, usamos un hash basado en el nombre
        return String(baseName);
    }

    /**
     * Determina la orientación de una imagen (horizontal, vertical o cuadrada)
     * basándose en sus dimensiones reales
     */
    async function determineImageOrientation(src) {
        return new Promise((resolve) => {
            const img = new Image();
            
            img.onload = function() {
                const width = this.width;
                const height = this.height;
                const ratio = width / height;
                
                // Clasificar según la relación de aspecto
                if (ratio > 1.2) {
                    resolve('horizontal');
                } else if (ratio < 0.8) {
                    resolve('vertical');
                } else {
                    resolve('square');
                }
            };
            
            img.onerror = function() {
                // Por defecto, asumir cuadrada si hay error
                resolve('square');
            };
            
            img.src = src;
        });
    }

    /**
     * Comprueba si una imagen existe
     */
    function checkImageExists(url) {
        return new Promise(resolve => {
            const img = new Image();
            img.onload = () => resolve(true);
            img.onerror = () => resolve(false);
            img.src = url;
        });
    }

    /**
     * Mezcla un array (algoritmo Fisher-Yates)
     */
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    /**
     * Crea un archivo index.json para la galería
     * Este paso es solo informativo, ya que en un entorno real,
     * este archivo debería crearse en el servidor
     */
    function createIndexJsonInfo() {
        console.log(`
IMPORTANTE: Para que la galería funcione correctamente, necesitas crear un archivo index.json
en la carpeta 'imagenes/galeria' con la siguiente estructura:

{
    "images": [
        "1.jpg",
        "2.jpg",
        "3.jpg",
        "4.jpg",
        "5.jpg"
        // ... otras imágenes
    ]
}

Cada entrada debe ser el nombre de archivo de una imagen en la carpeta raíz.
También puedes organizarlas en subcarpetas, por ejemplo: "subcarpeta/imagen.jpg".

Alternativamente, puedes habilitar CORS en tu servidor web para permitir
la lectura directa de archivos locales.
        `);
    }

    /**
     * Carga más imágenes en la galería con efecto de aparición secuencial
     */
    function loadImages(count) {
        if (isLoading) return;
        
        isLoading = true;
        showLoader();
        
        setTimeout(() => {
            const startIndex = displayedImages;
            const endIndex = Math.min(startIndex + count, allImages.length);
            
            // Si ya hemos mostrado todas las imágenes, ocultar botón "Cargar más"
            if (endIndex >= allImages.length) {
                loadMoreBtn.addClass('hidden');
            }
            
            // Añadir nuevas imágenes a la galería con aparición secuencial
            for (let i = startIndex; i < endIndex; i++) {
                const image = allImages[i];
                const delay = (i - startIndex) * 100; // Retardo escalonado
                
                setTimeout(() => {
                    addImageToGallery(image, i);
                }, delay);
            }
            
            displayedImages = endIndex;
            
            // Actualizar thumbnails del visor si está abierto
            if (customLightbox.hasClass('active')) {
                updateLightboxThumbnails();
            }
            
            // Terminar la carga después de cargar todas las imágenes
            setTimeout(() => {
                hideLoader();
                isLoading = false;
            }, (endIndex - startIndex) * 100 + 200);
            
        }, 300); // Pequeño retardo para efecto de carga
    }

    /**
     * Añade una imagen a la galería con animación
     */
    function addImageToGallery(image, index) {
        // Crear div con clase según orientación
        const galleryItem = $('<div>').addClass(`gallery-item ${image.type}`)
            .attr({
                'data-src': image.path,
                'data-id': image.id,
                'data-index': index
            });
        
        // Crear la imagen dentro del elemento
        const img = $('<img>').attr({
            'src': image.thumbPath,
            'alt': `Imagen BEMARO ${index+1}`,
            'class': 'gallery-img'
        });
        
        // Crear overlay con icono
        const overlay = $('<div>').addClass('gallery-overlay');
        const icon = $('<div>').addClass('icon');
        const iconI = $('<i>').addClass('fas fa-search-plus');
        
        icon.append(iconI);
        overlay.append(icon);
        
        // Añadir elementos al item y el item a la galería
        galleryItem.append(img);
        galleryItem.append(overlay);
        galleryGrid.append(galleryItem);
        
        // Animación de aparición con retardo
        setTimeout(() => {
            galleryItem.addClass('animate-in');
        }, 50);
        
        // Evento de clic para abrir el visor
        galleryItem.on('click', function() {
            const index = parseInt($(this).attr('data-index'));
            openLightbox(index);
        });
        
        // Manejar errores de carga de imagen
        img.on('error', function() {
            galleryItem.remove();
            
            // Eliminar la imagen del array
            allImages.splice(index, 1);
            
            // Ajustar índices
            $('.gallery-item').each(function(i) {
                $(this).attr('data-index', i);
            });
            
            // Reducir el contador
            displayedImages--;
            
            console.warn(`Error al cargar la imagen: ${image.path}`);
            
            // Si hay pocas imágenes, cargar más para evitar huecos
            if (displayedImages < 8 && displayedImages < allImages.length) {
                loadImages(1);
            }
        });
    }

    /**
     * Inicializa los eventos de la galería
     */
    function initEvents() {
        // Botón "Cargar más" con efecto de pulsación mejorado
        loadMoreBtn.on('click', function() {
            // Efecto de pulsación visual
            $(this).css({
                'transform': 'scale(0.95)',
                'box-shadow': '0 5px 15px rgba(0, 0, 0, 0.1)'
            });
            
            // Restaurar después de un breve retraso
            setTimeout(() => {
                $(this).css({
                    'transform': '',
                    'box-shadow': ''
                });
                
                // Cargar más imágenes solo cuando se presiona el botón
                loadImages(galleryConfig.loadMoreCount);
            }, 150);
        });
        
        // Eventos del visor de imágenes personalizado
        lightboxClose.on('click', closeLightbox);
        lightboxPrev.on('click', prevLightboxImage);
        lightboxNext.on('click', nextLightboxImage);
        
        // Teclas para navegar por el visor
        $(document).on('keydown', function(e) {
            if (customLightbox.hasClass('active')) {
                if (e.key === 'Escape') {
                    closeLightbox();
                } else if (e.key === 'ArrowLeft') {
                    prevLightboxImage();
                } else if (e.key === 'ArrowRight') {
                    nextLightboxImage();
                }
            }
        });
        
        // Cambiar de imagen con swipe en móviles
        let touchStartX = 0;
        let touchEndX = 0;
        
        customLightbox.on('touchstart', function(e) {
            touchStartX = e.originalEvent.touches[0].clientX;
        });
        
        customLightbox.on('touchend', function(e) {
            touchEndX = e.originalEvent.changedTouches[0].clientX;
            handleSwipe();
        });
        
        function handleSwipe() {
            const swipeThreshold = 100;
            if (touchEndX < touchStartX - swipeThreshold) {
                // Swipe izquierda: siguiente imagen
                nextLightboxImage();
            } else if (touchEndX > touchStartX + swipeThreshold) {
                // Swipe derecha: imagen anterior
                prevLightboxImage();
            }
        }
    }

    /**
     * Abre el visor de imágenes personalizado
     */
    function openLightbox(index) {
        if (index < 0 || index >= allImages.length) return;
        
        currentLightboxIndex = index;
        const image = allImages[index];
        
        // Mostrar el loader
        lightboxLoader.css('display', 'block');
        
        // Cargar la imagen
        const img = new Image();
        img.onload = function() {
            // Ocultar el loader
            lightboxLoader.css('display', 'none');
            
            // Mostrar la imagen
            lightboxImg.attr('src', image.path);
            lightboxImg.attr('alt', `Imagen BEMARO ${index + 1}`);
            
            // Actualizar contador
            updateLightboxCounter();
            
            // Generar miniaturas si es la primera vez
            if (lightboxThumbnails.children().length === 0) {
                createLightboxThumbnails();
            }
            
            // Actualizar miniatura activa
            updateActiveThumbnail();
        };
        
        img.onerror = function() {
            // En caso de error, cerrar el visor
            closeLightbox();
            console.error(`Error al cargar la imagen: ${image.path}`);
        };
        
        img.src = image.path;
        
        // Mostrar el visor
        customLightbox.addClass('active');
        $('body').css('overflow', 'hidden'); // Evitar scroll
    }

    /**
     * Cierra el visor de imágenes personalizado
     */
    function closeLightbox() {
        customLightbox.removeClass('active');
        $('body').css('overflow', ''); // Restaurar scroll
        
        // Limpiar la imagen actual después de cerrar
        setTimeout(() => {
            lightboxImg.attr('src', '');
        }, 300);
    }

    /**
     * Navega a la imagen anterior en el visor
     */
    function prevLightboxImage() {
        const newIndex = (currentLightboxIndex - 1 + allImages.length) % allImages.length;
        openLightbox(newIndex);
    }

    /**
     * Navega a la siguiente imagen en el visor
     */
    function nextLightboxImage() {
        const newIndex = (currentLightboxIndex + 1) % allImages.length;
        openLightbox(newIndex);
    }

    /**
     * Actualiza el contador del visor
     */
    function updateLightboxCounter() {
        lightboxCounter.text(`${currentLightboxIndex + 1} / ${allImages.length}`);
    }

    /**
     * Crea las miniaturas para el visor
     */
    function createLightboxThumbnails() {
        lightboxThumbnails.empty();
        
        allImages.forEach((image, index) => {
            const thumb = $('<div>').addClass('lightbox-thumb')
                .attr('data-index', index);
            
            const thumbImg = $('<img>').attr({
                'src': image.thumbPath,
                'alt': `Miniatura ${index + 1}`
            });
            
            thumb.append(thumbImg);
            lightboxThumbnails.append(thumb);
            
            // Evento de clic en miniatura
            thumb.on('click', function() {
                const clickedIndex = parseInt($(this).attr('data-index'));
                openLightbox(clickedIndex);
            });
        });
    }

    /**
     * Actualiza las miniaturas si se han cargado nuevas imágenes
     */
    function updateLightboxThumbnails() {
        // Obtener el último índice actual
        const lastIndex = lightboxThumbnails.children().length - 1;
        
        // Añadir miniaturas para las nuevas imágenes
        for (let i = lastIndex + 1; i < allImages.length; i++) {
            const image = allImages[i];
            const thumb = $('<div>').addClass('lightbox-thumb')
                .attr('data-index', i);
            
            const thumbImg = $('<img>').attr({
                'src': image.thumbPath,
                'alt': `Miniatura ${i + 1}`
            });
            
            thumb.append(thumbImg);
            lightboxThumbnails.append(thumb);
            
            // Evento de clic en miniatura
            thumb.on('click', function() {
                const clickedIndex = parseInt($(this).attr('data-index'));
                openLightbox(clickedIndex);
            });
        }
        
        // Actualizar contador
        updateLightboxCounter();
    }

    /**
     * Actualiza la miniatura activa en el visor
     */
    function updateActiveThumbnail() {
        lightboxThumbnails.find('.lightbox-thumb').removeClass('active');
        lightboxThumbnails.find(`.lightbox-thumb[data-index="${currentLightboxIndex}"]`).addClass('active');
        
        // Scroll a la miniatura activa
        const activeThumb = lightboxThumbnails.find('.active');
        if (activeThumb.length) {
            const scrollPosition = activeThumb.position().left + lightboxThumbnails.scrollLeft()
                - lightboxThumbnails.width() / 2 + activeThumb.width() / 2;
            
            lightboxThumbnails.animate({
                scrollLeft: scrollPosition
            }, 300);
        }
    }

    /**
     * Muestra el loader con animación
     */
    function showLoader() {
        galleryLoader.removeClass('hidden');
        
        // Animación de aparición
        galleryLoader.css({
            'opacity': '0',
            'transform': 'translateY(20px)'
        });
        
        setTimeout(() => {
            galleryLoader.css({
                'opacity': '1',
                'transform': 'translateY(0)',
                'transition': 'all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)'
            });
        }, 10);
    }

    /**
     * Oculta el loader con animación
     */
    function hideLoader() {
        galleryLoader.css({
            'opacity': '0',
            'transform': 'translateY(-20px)',
            'transition': 'all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)'
        });
        
        setTimeout(() => {
            galleryLoader.addClass('hidden');
        }, 500);
    }

    /**
     * Muestra un mensaje cuando no hay imágenes disponibles
     */
    function showEmptyMessage() {
        hideLoader();
        
        const emptyMessage = $('<div>').addClass('gallery-empty-message').css({
            'opacity': '0',
            'transform': 'translateY(20px)'
        }).html(`
            <i class="fas fa-images"></i>
            <h3>No hay imágenes disponibles</h3>
            <p>Actualmente no hay imágenes en la galería. Por favor, vuelve más tarde.</p>
        `);
        
        galleryGrid.html(emptyMessage);
        loadMoreBtn.addClass('hidden');
        
        // Animar la aparición del mensaje
        setTimeout(() => {
            emptyMessage.css({
                'opacity': '1',
                'transform': 'translateY(0)',
                'transition': 'all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)'
            });
        }, 100);
    }

    /**
     * Muestra un mensaje de error con animación
     */
    function showErrorMessage(message) {
        hideLoader();
        
        const errorMessage = $('<div>').addClass('gallery-error').css({
            'opacity': '0',
            'transform': 'translateY(20px)'
        }).html(`
            <i class="fas fa-exclamation-circle"></i>
            <p>${message}</p>
            <button class="retry-btn">Reintentar</button>
        `);
        
        galleryGrid.html(errorMessage);
        
        // Animar la aparición del mensaje
        setTimeout(() => {
            errorMessage.css({
                'opacity': '1',
                'transform': 'translateY(0)',
                'transition': 'all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)'
            });
        }, 100);
        
        // Botón de reintentar con efecto de pulsación
        errorMessage.find('.retry-btn').on('click', function() {
            // Efecto de pulsación
            $(this).css({
                'transform': 'scale(0.95)',
                'box-shadow': '0 2px 8px rgba(0, 0, 0, 0.1)'
            });
            
            // Restaurar después de un breve retraso
            setTimeout(() => {
                $(this).css({
                    'transform': '',
                    'box-shadow': ''
                });
                
                galleryGrid.empty();
                showLoader();
                initGallery();
            }, 150);
        });
        
        // Ocultar botón de cargar más
        loadMoreBtn.addClass('hidden');
    }
});