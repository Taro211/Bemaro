// Script para mostrar splash screen festivo por el Día del Niño
document.addEventListener('DOMContentLoaded', function() {
    const themeToggle = document.querySelector('.theme-toggle');
    
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            // Verificar si estamos cambiando a modo festivo (dark-mode)
            setTimeout(() => {
                if (document.body.classList.contains('dark-mode')) {
                    // Mostrar el splash festivo
                    showFestiveSplash();
                }
            }, 200); // Pequeño retraso para asegurar que la clase se haya aplicado
        });
    }
});

// Función para crear y mostrar el splash screen festivo
function showFestiveSplash() {
    // Crear el elemento del splash festivo
    const festiveSplash = document.createElement('div');
    festiveSplash.className = 'festive-splash-screen';
    
    // Añadir el contenido con énfasis en el mensaje festivo
    festiveSplash.innerHTML = `
        <div class="festive-splash-content">
            <h1 class="festive-title">¡FELIZ DÍA DEL NIÑO!</h1>
            <p class="festive-message">En BEMARO les deseamos un día lleno de alegría este 30 de abril</p>
            <img src="logo/logowh.svg" alt="Logo BEMARO" class="splash-logo">
        </div>
    `;
    
    // Añadir el splash al body
    document.body.appendChild(festiveSplash);
    
    // Crear y añadir estilos específicos para el splash festivo
    const style = document.createElement('style');
    style.textContent = `
        .festive-splash-screen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--theme-dark-accent) 0%, rgba(var(--theme-dark-accent-rgb), 0.92) 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            animation: fadeOutFestive 1.2s cubic-bezier(0.6, 0.05, 0.1, 0.9) forwards;
            animation-delay: 1.8s;
        }
        
        .festive-splash-content {
            text-align: center;
            max-width: 80%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .festive-title {
            color: white;
            font-family: "Faculty Glyphic", sans-serif;
            font-size: 3.2rem;
            margin-bottom: 0.5rem;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.4);
            animation: popIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
            opacity: 0;
            transform: scale(0.8);
            letter-spacing: 2px;
        }
        
        .festive-message {
            color: white;
            font-family: "Raleway", sans-serif;
            font-size: 1.5rem;
            margin: 0.5rem 0 1.5rem;
            line-height: 1.3;
            text-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            animation: fadeInUp 0.5s ease forwards;
            animation-delay: 0.2s;
            opacity: 0;
            transform: translateY(10px);
        }
        
        .festive-splash-screen .splash-logo {
            width: 40%;
            max-width: 180px;
            margin-top: 1rem;
            opacity: 0;
            animation: fadeIn 0.5s ease forwards;
            animation-delay: 0.4s;
            filter: drop-shadow(0 4px 10px rgba(0, 0, 0, 0.3));
        }
        
        @keyframes fadeOutFestive {
            0% { opacity: 1; }
            100% { opacity: 0; visibility: hidden; }
        }
        
        @keyframes fadeInUp {
            0% { opacity: 0; transform: translateY(10px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 0.85; }
        }
        
        @keyframes popIn {
            0% { opacity: 0; transform: scale(0.8); }
            50% { opacity: 1; transform: scale(1.1); }
            100% { opacity: 1; transform: scale(1); }
        }
        
        /* Estilos responsive */
        @media (max-width: 768px) {
            .festive-title {
                font-size: 2.5rem;
            }
            .festive-message {
                font-size: 1.2rem;
            }
        }
        
        @media (max-width: 480px) {
            .festive-title {
                font-size: 2rem;
            }
            .festive-message {
                font-size: 1rem;
            }
        }
    `;
    document.head.appendChild(style);
    
    // Crear y mostrar el confeti
    createConfetti();
    
    // Eliminar el splash después de la animación
    setTimeout(() => {
        festiveSplash.remove();
        style.remove();
    }, 3000); // 3 segundos total (1.8s delay + 1.2s animación)
}

// Función para crear efecto de confeti
function createConfetti() {
    // Número de piezas de confeti (aumentado para mejor visibilidad)
    const confettiCount = 200;
    
    // Colores festivos para el día del niño (más brillantes)
    const colors = [
        '#4089E0', // Azul (color del tema festivo)
        '#FFD700', // Amarillo dorado
        '#FF5252', // Rojo
        '#4CAF50', // Verde
        '#9C27B0', // Morado
        '#FF9800', // Naranja
        '#00BCD4', // Cian
        '#FF4081'  // Rosa
    ];
    
    // Crear un contenedor para el confeti
    const confettiContainer = document.createElement('div');
    confettiContainer.className = 'confetti-container';
    document.body.appendChild(confettiContainer);
    
    // Crear estilos para el confeti
    const confettiStyle = document.createElement('style');
    confettiStyle.textContent = `
        .confetti-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 10001;
            pointer-events: none;
            overflow: hidden;
        }
        
        .confetti {
            position: absolute;
            width: 15px;
            height: 15px;
            background-color: #f00;
            opacity: 0.9;
            animation-name: confetti-fall, confetti-shake;
            animation-timing-function: ease-in-out, ease-in-out;
            animation-iteration-count: 1, infinite;
            animation-fill-mode: both, both;
            animation-play-state: running, running;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        
        @keyframes confetti-fall {
            0% {
                top: -10%;
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                top: 105%;
                opacity: 0;
            }
        }
        
        @keyframes confetti-shake {
            0% {
                transform: translateX(0) rotate(0);
            }
            25% {
                transform: translateX(100px) rotate(90deg);
            }
            50% {
                transform: translateX(-100px) rotate(180deg);
            }
            75% {
                transform: translateX(100px) rotate(270deg);
            }
            100% {
                transform: translateX(-100px) rotate(360deg);
            }
        }
    `;
    document.head.appendChild(confettiStyle);
    
    // Crear las piezas de confeti (desde los laterales como solicitaste)
    for (let i = 0; i < confettiCount; i++) {
        // Crear una pieza de confeti
        const confetti = document.createElement('div');
        confetti.className = 'confetti';
        
        // Establecer lado desde el que aparecerá (izquierda o derecha)
        const side = i % 2 === 0 ? 'left' : 'right';
        const startPosition = side === 'left' ? '-5%' : '105%';
        
        // Tamaño aleatorio entre 8px y 15px (más grande para mejor visibilidad)
        const size = 8 + Math.random() * 8;
        
        // Posiciones aleatorias
        const x = startPosition;
        const y = Math.random() * 100 + "%";
        
        // Velocidad aleatoria (más rápido: entre 1.5s y 3s)
        const fallDuration = 1.5 + Math.random() * 1.5;
        const shakeDuration = 1 + Math.random() * 1;
        
        // Color aleatorio
        const color = colors[Math.floor(Math.random() * colors.length)];
        
        // Forma aleatoria (cuadrado, círculo o triángulo)
        const shapes = ['square', 'circle', 'triangle', 'star'];
        const shape = shapes[Math.floor(Math.random() * shapes.length)];
        
        // Aplicar propiedades
        confetti.style.left = x;
        confetti.style.top = y;
        confetti.style.width = `${size}px`;
        confetti.style.height = `${size}px`;
        confetti.style.backgroundColor = color;
        confetti.style.animationDuration = `${fallDuration}s, ${shakeDuration}s`;
        confetti.style.animationDelay = `${Math.random() * 1}s`; // Retraso reducido
        
        // Establecer la forma
        if (shape === 'circle') {
            confetti.style.borderRadius = '50%';
        } else if (shape === 'triangle') {
            confetti.style.width = '0';
            confetti.style.height = '0';
            confetti.style.backgroundColor = 'transparent';
            confetti.style.borderLeft = `${size/2}px solid transparent`;
            confetti.style.borderRight = `${size/2}px solid transparent`;
            confetti.style.borderBottom = `${size}px solid ${color}`;
        } else if (shape === 'star') {
            // Crear forma de estrella usando un elemento adicional
            confetti.style.backgroundColor = 'transparent';
            confetti.style.position = 'relative';
            
            // Usar pseudo-elementos para crear una estrella (simplificada)
            confetti.style.width = `${size}px`;
            confetti.style.height = `${size}px`;
            confetti.innerHTML = '★'; // Usar el símbolo de estrella
            confetti.style.color = color;
            confetti.style.fontSize = `${size*1.2}px`;
            confetti.style.textAlign = 'center';
            confetti.style.lineHeight = `${size}px`;
        }
        
        // Añadir al contenedor
        confettiContainer.appendChild(confetti);
        
        // Eliminar después de la animación
        setTimeout(() => {
            confetti.remove();
        }, fallDuration * 1000 + (Math.random() * 1) * 1000); // Tiempo reducido
    }
    
    // Eliminar el contenedor después de completar todas las animaciones
    setTimeout(() => {
        confettiContainer.remove();
        confettiStyle.remove();
    }, 5000); // Reducido a 5 segundos
}